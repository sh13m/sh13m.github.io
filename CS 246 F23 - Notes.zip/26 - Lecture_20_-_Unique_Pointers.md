
- Recall: MVC

```mermaid
classDiagram

Model -- Controller
View -- Controller

class Model
class View
class Controller 
```

- Model - can have multiple views (e.g. text and graphics)
	- doesn't need to know their details
	- classic Observer pattern (or could communicate through the controller) 

- Controller: mediates control flow through model and view
	- may encapsulate turn-taking, or full game rules
	- may communicate with the user for input (or this could be the view)

Exception Safety
---

- Consider:

```C++
void f(){
	C c; 
	C *p = new C;
	g();
	delete p;
}
```

- No leaks, but what if g throws? 
	- During stack unwinding all stack-allocated data is cleaned up (dtors run, memory is reclaimed) 
	- Heap-allocated memory is not reclaimed
	- If g throws, c is not leaked, but `*p` is 

```C++
void f() {
	C c;
	C *p = new C;
	try {
		g();
	}
	catch (...){ //error prone, duplication of code (delete p twice)
		delete p;
		throw;
	}
	delete p;
}
```

- How else can we guarantee that everything (e.g. delete p) will happen, no matter how we exit f (normal or by exception)?
- In some languages - "finally" clauses guarantee certain final actions - not in C++ 
- The only thing you can count on in C++ - dtors for stack allocated data will run 
	- Use stack allocated data with dtors as much as possible 
	- Use the guarantee to your advantage 

- **C++ Idiom**: RAII (Resource Acquisition Is Initialization) 
	- Every resource should be wrapped in a stack-allocated object, whose job is to delete it 

- Example: files

```C++
{
	ifstream f {"file"}; //acquiring the rescource ("file") 
						 //initializing the object (f)
	...
} //the file is guaranteed to be released when f is popped from the stack
  // (since f's dtor runs)
```

- This can be done with dynamic memory 

```C++
class std::unique_pointer<T> //(import <memory> library)
```

- Takes a T* in the ctor 
- The dtor will delete the pointer
- In between - can dereference, just like a pointer 

```C++
void f(){
	C c;
	std::unique_pointer<c> p {new C};
	g();
} //no leaks, guaranteed 
```

- Alternative: 

```C++
void f(){
	C c;
	auto p = std:: make_unique<c>(); //allocates a c object on the heap and
									 //puts a pointer to it inside a 
									 //unique_pointer object
}
```

- Ctor arguments go in (), if there are any

- Difficulty: 

```C++
unique_pointer<c> p {new C};
unique_pointer<C> q = p; //X
```

- What would happen if a unique pointer were copied?
	- Don't want to delete the same pointer twice 
	-  Instead, copying is disabled for unique pointers - they can only be moved 

```C++
template <typename T> class unique_ptr{
		T *ptr;
	public:
		explicit unique_ptr (T *p): ptr {p} {}
		~unique_ptr () {delete ptr;}
		
		unique_ptr (const unique_ptr &other) = delete;
		unique_ptr<T> operator=(const unique_ptr &) = delete

		unique_ptr (unique_ptr &&other): ptr {other.ptr} {
			other.ptr = nullptr;
		}
		unique_ptr<T> operator=(unique_ptr &&other){
			if (this == &other) return *this;
			delete ptr;
			ptr = other.ptr;
			other.ptr = nullptr;
			return *this;
		}
		T &operator*() {return *ptr;}
		T *get() {return ptr;}
};
```

- If you need to be able to copy pointers - first answer the question of ownership 
- Who will own the resource? Who will have responsibility for freeing it?
	- That pointer should be unique
	- All other pointers should be raw pointers (can fetch the underlying raw pointer with p.get()) 

- New understanding of pointers: 
	- Unique pointer - indicates ownership 
		- delete will happen automatically when the unique pointers go out of scope
	- Raw pointer - indicates non-ownership
		- Since a raw pointer is considered not to own the resource it points at, you should not delete it
	- When you move a unique pointer - transfer of ownership 

- Pointers as parameters:

```C++
void f (unique_ptr<c> p); //f will take ownership of the object pointed to by p
						  //the caller loses custody of the object 

void g (C *p); //g will not take over ownership of the object pointed to by p
			   //the caller's ownership of the object does not change
```

- Note that the caller might also not own the object 

- Pointers as results:

```C++
unique_ptr<c> f(); //return by value is always a move
				   //f is handing over ownership of the C object to the caller

C *g(); //the ptr returned by g is understood not to be deleted by the caller
		//might represent a ptr to non-heap data, or to heap data that someone
		//else already owns 
```

- Rarely a situation may arise that calls for true **shared ownership**, i.e. any of several ptrs might need to free the resource 
	- Use std::shared_ptr

```C++
{auto p = std::make_shared <c> ()
	 if (...){
		 auto q = p;
	 } //q popped, ptr not deleted
 
 } //p is popped, pointer is deleted
```

- shared_ptrs maintain a **reference count** - count of all shared_ptrs pointing at the same object
- Memory is freed when the number of shared_ptrs pointing to it will reach 0

- Recall: In Racket

```Racket
(define l1 (cons 1 (cons 2 (cons 3 empty))))

(define l2 (cons 4 (rest l1)))
```


