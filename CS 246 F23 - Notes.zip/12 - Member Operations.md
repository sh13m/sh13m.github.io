Member Operations
-----------------
Some operations must be members of the class:  
- operator=  
- operator[]  
- operator->  
- operator()  
- operatorT(), where T is a type  

Consider Vec: arithmetic operators (where first parameter/LHS operand) can
              be either members of the class or stand-alone  
              => e.g.
```C++ 
Vec operator*(ubt s, Vec v);
// can't be member
Vec operator*(vec v, int s);
// can be member
```
If going to implement arithmetic operators, then should implement self-assignment
version first, then implement other in terms of self-assignment version
```C++
Vec & operator+=(Vec &a, const vec &b) {
    this->x = a.x + b.x;
    this->y = a.y + b.y;
    return *this;
}


Vec operator+=(Vec &v1, const Vec &v2) {
    v1.x += v2.x;
    v1.y += v2.y;
    return v1;
}

Vec operator+(const Vec &v1, const Vec &v2) {
    Vec temp{v1};
    return temp += v2; // uses already-written operator+=
}
```
Q: What about I/O operator? Should they be methods or "stand alone"?  
[e.g.]
```C++
struct Vec {
    ...
    ostream &operator<<(ostream &out) {
        out << x << ',' << y;
        return out;
    }
}
// gets order backwards would look like this in use
Vec v{1,0};
v << cout << "hello";
```
A: I/O should be stand alone because counter intuitive if a method
```C++
ostream &operator<<(ostream &out, const Vec &v) {
    ...
}
```

