References
----------
[IMPORTANT CONCEPT!]  
First need to define 2 new terms:  
  - lvalue: 
    - an object that can be accessed by name, by following the pointer  
      to it, or by using reference to it  
      e.g. int x; // x is lvalue  
  - rvalue:
    - not an lvalue ; usually a temporary object  
      e.g. int foo() {return 5;} // returned 5 is an rvalue  
```
int x = 5;
int &z = x;
```
- "z" is an lvalue reference
- "z" is an alias for variable "x", and is "bound" to "x"
- a reference is effectively a constant pointer that is automatically
  implicitly deferenced

```C++
int *ptr = &z;  // address of x, not z
z = 12;         // changes the value in x
[NOTE: z is not deferenced, i.e. not *z = 12]

void inc(int &n) {
    n = n + 1
}

int main() {
    int x {5};
    inc(x);
    cout << x << endl; // 6
}
```
- references can only be part of a variable declaration  
  e.g. \<type> &\<var_1> = \<var_2>;  
       int &z = x;
- if not part of declaration, is either an "address of" or bit-wise and  
  e.g. ptr = &x; 2 & 5;


[4 things that cannot be done with references]
1) cannot be left uninitialized
    ```
    e.g. int &z;            // NOT OK!
    => must be bound to an lvalue
       int &z = x;          // OK
       int &z = 3;          // NO!
       int &z = x + y;      // NO!
    ```

2) cannot have a pointer to a reference
    ```
    e.g. int &*z = ...;     // NO!
    => can have a reference to a pointer
       int *&z = ...;       // OK
    ```

3) no "reference to a reference" i.e. && means rvalue reference in C++   
    (wait until we discuss "move semantics")

4) can't have an array of references (constant, can't be initialized later)
    - same for std::vector, etc

Q: whar can you do with references?

A: pass as parameters (or return)
```C++
e.g. void f(int &n)
     void g(const int &n)
     f(5); // not allowed since n not const &
     g(5); // ok since g can't change n's value
```

Note: compiler must allocate space for rvalue 5 on run-time stack, to which
      lvalue ref n is bound in function call g

```C++
cin >> n; // uses an lvalue ref. for n
std::istream &operator>>(std::istream &in, int &val);
```

- Note that operator>> returns by ref.
- if returned by value, would copy the stream object, but they disallow copying  
  => return by ref. eliminates the copying  
  => side-effect: lets us "chain" calls  
     e.g. 
     ```
     cin >> x >> y >> z;
     cout << x << y << z << endl;
     ```

Q: how much does copying cost? (i.e. pass or return by value)

A: e.g. 
```C++
struct ReallyBig {...};
// costly, time-consuming
void f1(ReallyBig rb); // copies (ignoring ellision for now)
// cheap, fast, since address but f2 can change contents of rb
void f2(ReallyBig &rb);
// cheap, fast, and rb is const so can't be changed
void f3(const ReallyBig &rb);
```

=> if want same effects as pass-by-value and size > ptr, use const ref.
   otherwise, pass-by-value

Q: what if function needs to change object as part of its computation, but
   can't affect original?
   
A: either pass-by-value and accept cost of copy or passed as const-ref so
   make local copy

   e.g.
```C++
void f4(const ReallyBig &rb) {
    ReallyBig crb = rb; // make local copy
    // ...
}
```

- pass-by-value lets compiler optimize
