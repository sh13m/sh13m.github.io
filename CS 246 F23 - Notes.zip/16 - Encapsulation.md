Invariants and Encapsulation
----------------------------
Consider:
```C++
struct Node {
    int data; Node *next;
    ~Node() {delete next;}
};

Node n{1, new Node{2, new Node{3, nullptr}}};   // OK
Node n2{5, nullptr};                            // OK
Node n3{6, &n2};                                // FAILS since n2 is stack-allocated
```

- code relies on assumption that next is either nullptr or valid heap-allocated address

Invariant: assertion that must be true for life of object, etc.  
[e.g.] stack invariant: last thing inserted is first thing removed  

- if can't enforce invariants, can't (successfully) reason about code behaviour
  and correctness
- want to be able to "encapsulate" our code (modules, classes, etc)
  => treat as "capsule" i.e. opaque/black box
  => provides an abstraction by hiding implementation details
- can only access/manipulate through provided pubic interface that enforces the
  invariants

[e.g.]
```C++
struct Vec {
    Vec(); // defaults to pubic accessibility
    private:
        int x, y; // not accessible from "outside"
    public:
        Vec operator+(const Vec &o);
        ...
};

Vec v1;
v1.x; // illegal
```
- problem is that default accessibility visibility/accessibility of "struct"
  is "public" and we'd rather have "private"  
  => replace "struct" with "class"

[e.g.]
```C++
class Vec  {
    int x, y; // private by default
    public:
        Vec();
        ...
};
```

Consider encapsulating our List class:
```C++
// list.cc
export module list;
export class List {
    struct Node; // forward declaration
    Node *theList = nullptr;
    public:
        ~List();
        void addToFront(int n);
        int &ith(int i);
};

// list-impl.cc
module list;
struct List::Node { // nested class
    int data; Node *next;
    ~Node() {delete next;}
};

List::~List() {delete theList;}

- nested class can access anything static in List
  => if has List object/reference/pointer, can use it to access any private or 
     public data/methods

void List::addToFront(int m) {
    theList = newNode{n, theList};
}

int & List::ith(int i) {
    Nofrde *curr = theList;
    for (int j = 0; j < i; j++, curr = curr->next);
    return cur->data;
}
```
- since only List can manipulate Node, invariant about next can be maintained  
  - setters/getters  
  - accessors/mutators  

- traversal over list is now O(n^2), not O(n)  
  => introduce Iterator design pattern
