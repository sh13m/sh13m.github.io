Inheritance
-----------
- often also referred to as either "generalization" or "specialization"
- discover and refactor commonalities  
  => "general" form is called "super" or "parent" class  
  => "special" form is called "sub" or "child" class  
  => A "is a" B
```
  [B] parent    [Student]
  △               △           --[Arts Student]
  |                |-----------|
  [A] child     [Math Student]
```
- don't put multiplicity, "is a" there is no multiplicity

Consider your library of Book, Text, and Comic objs
```
______________________
|Book                |
|--------------------|*
| - title: String    |<---|
| - author: String   |    |
| - numPages: Integer|    |
|____________________|    |
______________________    |
|Text                |    |
|--------------------|    |
| - title: String    |    |------◆[Collection]
| - author: String   |<---|
| - numPages: Integer|    |
| - topic: String    |    |
|____________________|    |
______________________    |
|Comic               |    |
|--------------------| *  | 
| - title: String    |<---|
| - author: String   |
| - numPages: Integer|
| - hero: String     |
|____________________|
```
Q: what if don't want Collection to have 3 separate arrays?

A: C-style union [e.g.]
```C
union BookTypes {
    Book *bptr;
    Text *tptr;
    Comic *cptr;
};
BookType arr[...];
```
=> requires another parallel data structure that tracks what as stored for every
   union element (see "tagged union")  
=> easy to make mistakes!
Alternatively, use array of (void *); not type-safe and still needs parallel
structure to know what was stored

Instead use inheritance:
```
______________________    _______________________
|Book                |    |Text                 |
|--------------------|    |---------------------|
|- author: String    |    | - topic: String     |
|- title: String     |◁---|---------------------|
|- numPages: Integer |    | + isHeavy(): Boolean|
|--------------------|    |_____________________|
|+ isHeavy(): Boolean|
|____________________|    
      △
______|_______________
|Comic               |
|--------------------|
|- hero: String      |
|--------------------|
|+ isHeavy(): Boolean|
|____________________|
```
```C++
class Book {
    string author, title;
    int numPages;
    public:
    bool isHeavy() {
        return numPages >= 200;
    }
    ...
};

class Text: public Book {
    string topic; // already inherited everything else!
    public:
    bool isHeavy() {
        return getNumPages() > 500;
    }
};

class Comic: public Book {
    string hero;
    public:
    bool isHeavy() {
        return getNumPages() >= 32;
    }
};
```
Book must have a non-default ctor:
```C++
  Book(string a, string t, int n): author{a}, title{t}, numPages{n} {}
```
=> object creation steps expanded:
  - allocate space
  - call parent ctor <--- if no default ctor, must be called in MIL
  - run ctor body
  
=> Text ctor becomes:
```C++
  Text::Text{string a, string t, int n, string topic}
    : Book{a, t, n}, topic{topic} {}
```
=> Comic ctor is similar!
[e.g.]
```C++
Book b{"Seaosns q", "Sleeping in the light", 250};
Text t{"Effective C++", "Fowler", 500, "C++"};
Comic *cptr = new Comic{...};
Book *bptr = &t; // legal
bptr = cptr; // legal
cout << cptr->isHeavy(); // true
cout << b.isHeavy(); // true
cout << bptr->isHeavy(); // calls Book::isHeavy() => true, not Text::isHeavy(); => false 
```
=> need to tell compiler to not statically hard-code which method to call  
   => must be done dynamically at run-time => "vitrual"
```
|--------------------------------------------------------------|
|                 | Who can access                             |
| Access Modifier |--------------------------------------------|
|                 | child class (public inh.) | everybody else |
|-----------------|---------------------------|----------------|
| public (+)      | yes                       | yes            |
|-----------------|---------------------------|----------------|
| protected (#)   | yes                       | no             |
|-----------------|---------------------------|----------------|
| private         | no                        | no             |
|--------------------------------------------------------------|
```
[e.g.] 
```C++
Book b{"Ancillary Justice", "Arn Leckie", 591};
Comic c{""War of the Gods, "George Prez", 1000, "Wonder Woman"};
```
Q: what happens if: 
```
b = c;
```
  ?

A: compiles and runs but has "object-slicing"

=> lost the extra data fields  
=> can only call book methods

Q: what happens for:
```C++
c = b;          // does not compile
c = Text{...};  // does not compile
```
  ?

A: will not compile because different types (no operator=)

- if use pointers (or references) of the parent class type to point to
  (or bind to) an object of the child class, there's no slicing!

=> if want a collection that can hold all three types transparently, need
   a "collection" of the pointers  
=> don't use array of parent class objects!

- we are trying to achieve "polymorphism"  
  i.e. call the right method by determining (dynamically) at run-time, rather
       than statically at compile-time, what the object type is, and finding the
       method

=> need 
1) reference/pointer
   
2) at least 1 vitrual method in the parent class
   
=>
   - in UML class model, use italics for vitrual methods  
   - (standard says it's for class name that has pure virtual methods, and pure virt. methods themselves)  

```C++
class Book {
  ...
  public:
  virtual bool isHeavy();
  ...
};

class Comic : public Book {
  ...
  public:
  bool isHeavy(); // inherits virtual
  // virtual bool ...; / fine
  // virtual book isHeavy() override; // better!
};
```

- can use "override" to have compiler help you by flagging differences in
  mehtod signature from that of the parental methods being overridden
```C++
// repo: 19-inheritance/example 5

class X {
  int *x;
  public:
  X(int n) : x{new int[n]} {}
  ~X() {delete[] x;}
};


class Y: public X {
  int *y;
  public:
  Y(int n, int m) : x{n}, m{new int[m]} {}
  ~Y() {delete[] y} // calls X::~X() not Y::~Y() since dtors not virtual
};

int main() {
  X x{5};
  Y y{5, 10};

  X *xp == new &{5, 10};
  delete xp;
}
```
Best practices:
1) if a class is already a base class, or might become one, make dtor vitrual

2) if want to enforce that a class cannot be inherited, declare it "final"
   
    [e.g.] 
    ```C++ 
    class A final {...};
    class Y final : public X {...}; // Y can't be inherited
    ```

3) if overriding methods in a subclass, use "override"
