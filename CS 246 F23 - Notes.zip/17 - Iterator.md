Design Patterns: is a common solution approach at the class-level  
                 => focuses on classes and their relationships

Iterator: abstraction of a pointer used to traverse a data structure

```C++
class List {
    public:
        class Iterator {
            Node *curr;
            public:
                Iterator(Node *c): curr{c} {}
                int & operator*() {return curr->data;}
                Iterator & operator++() {curr = curr->next; return *this;}
                bool operator!=(const Iterator &o) {return curr != o.curr;}
        };
        Iterator begin() const {return Iterator{theList};}
        Iterator end() const {return Iterator{nullptr};}
        ...
};

List myL;
...
List::Iterator it = myL.begin();
while (it != myL.end()) {
    cout << *it << endl;
    ++it;
}


List myList;
...
for (auto it = myList.begin(); it !=myList.end(); ++i) {
    cout << *it << endl;
}
```

- language provides a "range-based" for loop as a shortcut
  
[e.g.]
```C++
for (auto n : myList) {
    cout << n << endl;
}
```
- note that n is a copy in previous formm  
  => if want to be able to change it, make it a reference

[e.g.]
```C++
for (auto &n : myList) {
    n += 2;
}
```

Encapsulation, cont
-------------------
Since ```List::Iterator``` ctor is public

[e.g.]

```List::Iterator it1{nullptr}, it2{1234};```

=> want client to only be able to obtain an iterator through List::begin() or
   List::end()  
=> must be private!
```C++
class List {
    ...
    public:
        class Iterator {
            ...
            Iterator(Node *p) : ptr{p} {}
            public:
                ...

        }
        ...
};
```
=> but now List can't create an Iterator!  
=> make List a "friend" of Iterator  

[e.g.]
```C++
...
class Iterator {
    friend class List;  // can be either public or private, and placed anywhere in Iterator class
    ...
    };
    ...
};
```
- now that we encapsulate using "class", our only 2 means of getting things are:
1) friendship  
    => should be rare since lets friend access everything

2) add accessors/getters and mutators/setters

[e.g.]
```C++
// v1
class Vec {
    int x, y;
    friend ostream &operator<<(ostream ostream &out, const Vec &v);
    ...
};

ostream &operator<<(ostream ostream &out, const Vec &v) {
    out << v.x << ", " << v.y;
    return out
}
```
[e.g.]
```C++
// v2
class Vec {
    int x, y;
    public:
        int getX() const {return x;}
        void setX(int g) {x = g;}
        ...
};
ostream &operator<<(ostream &out, const Vec &v) {
    out << v.getX() << ", " << v.getY();
    return out;
}
```