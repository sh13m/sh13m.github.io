Classes
-------
A "class" is a type; a collection of data fields and functions.  
A variable of the class is an "object" or "instance" of the class.
- in C++, can use either "struct" or "class" keyword when defining the type
- will see "class" later
[e.g.]
```C++
export struct Student {     // class name: Student
    int assns, mt, final;   // data fields/members
    float grade();          // method/member function
};

// main.cc
...
Student s{80, 70, 60};
cout << s.grade() << endl;
```
=> grade is "called" in "s", which is the "recipient object"

```C++
// student-impl.cc
float Student::grade() {    // "::" is the "scope resolution operator"
    // recipient objects data fields are used
    return assns*0.5 + mt*0.2 + final*0.3;
}
```
- all methods of the class have a hidden, implicit first field called "this"  
=> "this" is always a pointer e.g. (Student *)
[e.g.]
```C++
float Student::grade() {
    return this->assns*0.5 + this->mt*0.2 + this->final*0.3;
}
```
In this course, always put your implementation code i the implementation file
rather than "inline"


Initialization
--------------
A "constructor" (ctor) is a method used to initialize objects.  
=> no return type, takes name of class as function name, has 0 (or more)
   parameters

- compiler provides a "default constructor"
  (0-parameter ctor; calls default ctor for all object fields)
- as soon as you define any ctor, the compiler-provided one is gone  
  
=> an object being created is always initialized by a ctor call

Q: how to define a ctor?

A: [e.g.]
```C++
struct Student {
    int assns, mt, final;
    float grade();

    Student(int assns = 0, int mt = 0, int final = 0);
};
...
Student s;                  // illegal because lost compiler given constructor (unless default values are given)
Student t{80, 70, 60};      // now a ctor call instead of field initialization

Student::Student(int assns, int mt, int final) {
    this->assns = assns;
    this->mt = mt;
    this->final = final;
}
```

NOTE: default values for ctor must go in interface

Q: will this compile?
```C++
struct Vec {
    int x, y;
    Vec (int x, int y);
};
struct Basis {
    Vec v1, v2;
    // WILL NOT COMPILE UNLESS ADD CTOR
    Basis (const vec &v1, const vec &v2);
}
Basis b;    // NOT OK
Basis d{Vec{0, 1}, Vec{1, 0}};

Basis::Basis(const vec &v1, const vec &v2) {
    this->v1 = v1;  // too late, not ctor calls
    this->v2 = v2;
}
```
- need ctor calls to occur between the allocation of the object's space
  and the execution of the ctor body

Notes:
1) "Student s;" is equivalent to "Student s {};"
2) "Student s{60, 70, 80};" is equivalent  "Student s = Student{60, 70, 80};"  
    => Second form is a constructor call, not assignment  
       i.e. passes rvalue Student{60, 70, 80} to s's constructor call - will see later


Object Creation Steps
---------------------
1) Allocate object space.
2) Construct fields => data fields that are objects need ctors called
3) Constructor body runs => fields must exist and be initialized

Use Member Initialization List (MIL)  
=> must be used for: references, constants, and ctor calls  
=> use the MIL as much as possible!  
[e.g.]
```C++
struct Basis {
    Vec v1{0, 1}, v2{1, 0};
    Basis() {}
    Basis(const Vec &va, const Vec &vb): v1{va}, v2{vb} {}
};
```
- if data field is listed in ctors MIL, then we ignore "default initial values" in line;
- MIL can only for ctors

[e.g.]
```C++
struct Student {
    int assns, my, final;       // not objects
    string name;                // object
    Student(int a, int m, int f, const string &n);
};

Student::Student(int a, int m, int f, const string &n)
    : assns{a}, mt{m}, final{f} {name = n;}
```
1) name default-constructed to empty string (step 2 of object creation)
2) copies n into name (step 3)  
    => would be more efficient to pass n to name's ctor

Note: compiler initializes data fields in declaration order, regardless
      of MIL order  
      => warning if orders don't match

```C++
Student::Student(int a, int m, int f, const string &n)
    : assns{a}, mt{m}, final{f}, name{n} {}
```

Consider
```C++
Basis::Basis(const Vec &v1, const Vec &v2)
    : v1{v1}, v2{v2} {}
```

What is the ctor call for v1 (or v2)?  
This is a copy constructor; compiler gives you one if you don't define it

```C++
Student fred{75, 80, 99, "fred"};
Student fred2 = fred; // same as "Student fred2{fred};"
```
- default copy ctor:
    - field-by-field copy for non-objects
    - copy ctor for object data fields

FORM: \<class-name>(const \<class-name> & );  
e.g. Student (const Student &s);

Q: what methods does the compiler provide for your class if you don't provide them?

A: 
```
   default constructor (0-parameters)
   copy constructor  ‾|
   move constructor   |
   destructor         |- big 5
   copy assignment    |
   move assignment   _|
```
```C++
Student::Student(const Student &other)
    : assns{other.assns}, mt{other.mt}, final{other.final}, name{other.name} {}
                                                            // copy ctor call!
```

Q: when is the default copy action insufficient?

A: when "shallow" copy isn't good enough i.e. want "deep" copy

Consider:
```C++
Struct Node {
    int value;
    Node *next; // next is a pointer, not an object
};

Node n{1, new Node{2, new Node{3, nullptr}}};
Node m = n; // same as Node m{n};
Node *ptr = new Node{m};
delete ptr; (%)
```
```
STACK      HEAP
n: [1] ----> [2] -> [3] -> "
             ^^
m: [1] ______||
              |
              |
ptr -------> [1] (%)
// once n and m freed on stack [2] [3] memory leak
```

[HOW TO HANDLE]
```C++
Node::Node(const Node &other) 
    : values{other.value}, 
      next {other.next == nullptr? nullptr : new Node{*other.next}} // copy ctor call!
      {}
```
Q: when do copy ctors get called?

A: For now: 
- when pass or return objects by value
- explicitly calling copy ctor as part of declaration  
              e.g. Node n{m};

[Aside: ellision changes this!]

Q: why is this wrong?
```C++
Node::Node(Node other) ... ?
```
A: Passed by value, not reference => attempts to copy Node, but trying to
   implement copy ctor!


Perils of single-parameter constructors
---------------------------------------
Consider:  
[e.g]
```C++
std::string s = "hello";     // "s" is string ctor call, "hello" is const char *
```
- std::string has a ctor that takes a (const char *)  
  => if ctor has a single parameter of a different type, used for type conversion

Now consider:  
[e.g.]
```C++
struct Node {
    ...
    Node(intv, Node *n = nullptr);
};
void f(Node n);

Node n1{4};
Node n2 = 4;
f(4);               // coerced into a Node
```

Issue: 
- Silent conversion, without compiler warnings!  
- Makes find the error hard.
- Really would like instead for the compiler to flag these  
=> let the compiler help you!  
=> Mark ctor with "explicit" keyword  

[e.g.]
```C++
struct Node {
    ...
    explicit Node(int v, Node *n = nullptr);
};
Node n1{4};     // OK
Node n2 = 4;    // Now illegal!   =>   Node n2 = Node{4};   // OK
f(4);           // Now illegal!        f(Node{4});          // OK
```

Destructors
-----------
Called when:
1) Object on run-time stack goes "out of scope"  
    ```{Node n;} <- n's destructor (dtor) called```
2) Object on heap and freed via delete  
    ```C++
    Node *p = new Node{...};
    ...
    delete p; <- call's dtor
    ```
Destructor form:  
- no return type
- no parameter list => no overloading!
- name is : "~<class-name> e.g. ~Node();
- used for specific "clean up" upon object termination
- compiler provides a "default" destructor

Object destruction steps:
1) Execute code in body of destructor
2) For any data fields that are themselves objects, run their destructors   
    => opposite order to creation
3) Free object-space

[e.g.]
```C++
struct Node {
    ...
    ~Node() {delete next;}
};
Node n1{1, new Node{2, new Node{3, nullptr}}};
Node *p = new Node{4, new Node{5, nullptr}};
delete p;
```
