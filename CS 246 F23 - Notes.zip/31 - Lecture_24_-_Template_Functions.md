
```C++
template <typename T> T min(Tx, Ty){
return x < y ? x: y;
}

int f(){
	int x = 1, y = 2;
	int z = min(x, y); //C++ infers T = int from the types of x + y
}
```

- If C++ can't determine T, you can tell it 
	- `int z = min<int>(x, y);`
	- min('a', 'c'); (T = char)
	- min(1.0, 3.0); (T = double)
- For what types T can min be used? For what types does the body compile? 
	- Any type for which operator< is defined

------------------------------------------------------------------------

- Recall: Abstract Iterator

```C++
void forearch(AbstractIt &start, AbstractIt &finish, void (*f)(int)){
	while (start != finish){
			f(*start);
		++start;
	}
}
```

- Subtypes of Abstract Iterator support `!=, *, ++`
- f can be called as a function
- Make these template args: 

```C++
template<typename Iter, typename Fn>
void foreach(Iter start, Iter finish, Fn f){
	//same as before
}
```

- Now Iter can be any type that supports `!= , ++, *` (including raw pointers)

```C++
void f(int n){cout << n << endl};
int a[] = {1, 2, 3, 4, 5};

foreach(a, a + 5, f); //prints each elemnt in array
```

- `<algorithm> library`: suite of template functions, iterating over containers 
- Examples: for_each (as above)

```C++
template<typename Iter, typename T>
Iter find (Iter first, Iter last, const T &val){
	
}
```

- Return iterator to first item `[first, last)` matching val
- Or last, if not found

- count - like find, but returns the number of occurrences of val

```C++
template<typename InIter, typename OutIter>
OutIter copy(InIter first, InIter last, OutIter result){

}
```

- Copies one container range `[first last)` to another, starting at result 
- Note: does **not** allocate memory 
- Example:

```C++
vector v {1, 2, 3, 4, 5, 6, 7};
vector<int> w (4); //0, 0, 0, 0

copy (v.begin() + 1, v.begin() + 5, w.begin());
//w = {2, 3, 4, 5};
```

```C++
template<typename InIter, typename OutIter, typename Fn>
OutIter transform(InIter first, InIter last, OutIter result, Fn f){
	while (first != last){
		*result = f(*first);
		++first;
		++result;
	}
	return result;
}
```

- Example:

```C++
int add1(int n){return n + 1;}
...
vector<int> v {2, 3, 5, 7, 11};
vector<int> w (v.size());
transform (v.begin(), v.end(), w.begin(), add1);
//w = {3, 4, 6, 8, 12}
```

- How generalized is this code?
	1. What can we use for Fn?
	2. What can we use for InIter/OutIter

1. Fn - How is f used? `f(*start)`
	- f can be anything that can be used as a function
	- Can write operator() for objects

```C++
class Plus1{
	public:
		int operator()(int n){return n + 1;}
};

Plus1 p;
p(4); //5

transform(v.begin(), v.end(), w.begin(), Plus1{}); //must call ctor for Plus1
```

- Generalize: 

```C++
class Plus{
		int m;
	public:
		Plus(int m): m {m};
		int operator()(int n) {return n + m;}
};

transform(v.begin(), v.end(), w.begin(), Plus{1});
```

- Plus1{}, Plus{1}, p - called function objects (sometimes functors) 
- Advantage of function objects - can maintain state 

```C++
class IncreasingPlus{
		int m = 0;
	public:
		int operator()(int n) {return n + (m++);}
		void reset() {m = 0;}
};

vector<int> (5, 0);
vector<int> w (v.size(), 0);

transform(v.begin(), v.end(), w.begin(), IncreasingPlus{});
//w = {0, 1, 2, 3, 4}
```

- Consider: How many ints in a vector v are even?

```C++
vector v {...}
bool even(int n) {return n % 2 == 0;}
int x = count_if(v.begin(), v.end(), even); //if this were Racket, we might 
											//use a lambda
int x = count_if(v.begin(), v.end(), w.begin(), [](int n){return n % 2 == 0;});
```

2. Iterators 
	- Apply the notion of iteration to other sources, e.g. streams

```C++
import<iterator>;

vector v {1, 2, 3, 4, 5};
ostream_iterator<int> out {cout, ", "};
copy(v.begin(), v.end(), out); //prints 1, 2, 3, 4, 5, 

vector<int> w;
copy(v.begin(), v.end(), w.begin()); //X copy doesn't allocate space in w
									 //it can't, doesn't even know that it's 
									 //iterating over a vector
```

- But what if we had an iterator whose assignment operator inserts a new item?

```C++
copy(v.begin(), v.end(), back_inserter(w)); //copies v to the end of w
											//adds new items
```

- Available for any container with a push_back method

**Range Abstraction**

- Consider the method `vector<T>::erase`
	- Takes an iterator to the item 
	- Removes the item
	- Shuffles the following items back 
	- Returns an iterator to the point of erasure  
- O(n) cost for shuffling items 

- What if you need to erase several consecutive items? 
	- Would you call erase repeatedly? (pay O(n) cost multiple times)
- Faster - shuffle the items up k positions (in one step each), where k is the number of items being erased 
- For this reason, most methods come with a "range" version:

```C++
iterator vector<T>::erase(iterator first, iterator last); 
```

- Erases items in `[first, last)` - only pays the linear cost once 

- Recall: transform takes two iterators, specifying a range `[first, last)` on input
	- So maybe iterator isn't the right level of abstraction 
	- Maybe the right abstraction encapsulates a pair of iterators - a range 

- Consider - composing multiple functions on some input 
	- Example: filter + transform - say, take all the odd numbers and square them

```C++
auto odd = [](int n) {return n % 2 != 0;}
auto sqr = [](int n) {return n * n;}
vector v {...}
vector<int> w (v.size()), x (v.size());

copy-if(v.begin(), v.end(), w.begin(), odd);
transform(w.begin(), w.end(), v.begin(), sqr);
```

- Problems:
1. Calls don't compose well 
2. Intermediate storage - on-demand fetching

- What if copy_if + transform returned a range?
	- `(transform(copy-if(v, odd), sqr)` 
- Range adapters - have operator| defined, so that R|A maps to A(R) 

```C++
auto x = v|filter(odd)|transform(sqr);
```