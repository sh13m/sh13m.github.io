Templates
---------
- large topic; we'll start with template classes
- Standard Template Library (STL) provides many useful templated abstract data
  types e.g. std::vector, std::map, etc.
- compiler needs to know entire class definition, including implementation, by
  the point where you declare your instance of the template class  
  => your entire class definition must be in the header file

[e.g.]
```C++
template<typename T> class Stack {
    // typename or class completely interchangable
    // "T" is convention for typename
    int size = 0;
    T *arr = nullptr;
    
    public:
    int getSize() const {return size;}
    T top() const {...}
    void push(T value) {...}
    void pop() {...}
};


template<typename T> class List {
    struct Node {
        T data;
        Node *next;
    };
    Node *theList = nullptr;

    public:
    class Iterator {
        friend class List;
        Node *ptr;
        Iterator(Node *p) : prt{p} {}

        public:
        T &operator*() {...}
        bool operator!=(const Iterator &other) {...}
        Iterator &operator++() {...}
    }
    Iterator begin() {...}
    Iterator end() {...}
    void add(T val) {...}
    T &ith(int i) {...}
};

List<int> list1;
list1.add(3);
List<List<int>> list2;
list2.add(list1);

for (List<int>::iterator it = list1.begin(); it != list1.end(); ++it) {
    std::cout << *it << endl;
}

for (auto elem : list1) { // for (auto &elem : list1) ... if don't want copy
    cout << elem << endl;
}
```

STL std::vector
---------------
Implemented as a dynamically-resizable array  
Notes: 
- library \<vector>
- part of std namespace
- type T must allow move/copy due to resizing
- if want vector of objects, either T must have default ctor, or 
    1) reserve enough space for all N objects
   
    2) make N std::vector::emplace_back calls, where parameters are ctor
             parameters e.g.
        ```C++
        class Vec {int x, y; public: Vec(int x, int y);}
        std::vector<Vec> v;
        v.reserve(5);
        for (int i = 0; i < 5; ++i) v.emplace_back(i,i+1);
        ```
```C++
vector<int> v1; //empty
vector<int> v2{1,2};
// vector v2{1,2}; //ok, deduces <int>
vector<int> v3(4,5); // v3 contains: 5,5,5,5
v3.push_back(6); // adds to end; not ctor call
if (v1.size() > 0) {cout << v1.back(); v1.pop_back();}
for (int i = 0; i < v2.size(); ++i) {
    cout << v2[i] << endl;
}

for (auto it = v2.begin(); it != v2.end(); ++it) {
    cout << *it << endl;
}

for (auto rit = v2.rbegin(); rit != v2.rend() ++rit) {
    cout << *rit << endl;
}
```

- v[i]: unchecked access
- v.at(i): checked access; raises exceptions

Q: consider vector of ints, v, and we want to remove all instances of the number 5

A:

Approach 1:
```C++
for (auto it = v.being(); it != v.end(); ++it) {
    if (*it == ) v.erase(5);
}
```
```
Let's say v: 1, 5, 5, 4, 3
                     [it]
          v` : 1, 5, 4, 3, ...
```
=> misses next occurence sine pre-incremented it;

Change code to:
```C++
for (auto it = v.being(); it != end();) {
    if (*it == 5) {it = v.erase(it);} // location of removed element
    else {++it;}
}
```
=> any add/remove to std::vector invalidates the iterator  
   => "refresh it"
