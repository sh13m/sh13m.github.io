
STL Maps - for creating dictionaries
--
- Example: "arrays" that map strings to ints 

```C++
import <map>;

std::map <std::string, int> m;
m["abc"] = 2;
m["def"] = 3;

cout << m["ghi"] //0, key isn't present, so it is inserted and the value is
				 //default constructed (0 for ints)
	 << m["def"]; //3

m.erase("abc");

if (m.count("def")) ... //0 = not found, 1 = found
```

- Iterating over a map -> sorted key order 

```C++
for (auto &p : m){
	cout << p.first << ' ' < p.second << endl;
} //
  //
```

- first - key, second - value
- both are fields
- p has type `std::pair<string, int>` `(<utility>)`
- std::pair is implemented as a struct, not as a class (fields are public) 

- In general: using "class" implies you are making an abstraction, with invariants that must be maintained 
	- "struct" signals that this is purely a conglomeration of values, no invariants, all field values are valid

- Alternatenatively:

```C++
for (auto &[key, value] : m){ //known as a structured binding
	cout << key << ' ' << value << endl;
}
```

- Structured bindings can be used on any structure (or class) type with all  public fields

```C++
Vec v {1, 2}; //assume public fields

auto [x, y] = v; //x = 1, y = 2

//or on a stack array of know size:

int a[] = {1, 2, 3};

auto [x, y, z] = a; //x = 1, y = 2, z = 3
```

- What should go into a module? 
	- So far - each class gets its own module 
	- But a module can contain any number of classes and functions 
	- When should classes/functions be grouped together in a module and when should they be in separate modules?

**Two Measures of Design Quality** 

- Coupling and cohesion 
- Coupling - how much distinct program modules depend on each other  
	- Low - modules communicate via function calls with basic parameters/results
		- modules pass arrays/structs back and forth 
		- modules affect each other's control flow 
		- modules share global data 
	- High - modules have access to each other's implementation (i.e. friends) 

- High coupling - changes to one module requires greater changes from other modules
	- Harder to reuse individual modules 

- Cohesion - how closely elements of a module are related to each other 
	- Low - arbitrary grouping of unrelated elements (e.g. `<utility>`) 
		- elements share a common theme, but otherwise are unrelated, maybe some common base code (e.g. `<algorithm>`) 
		- elements manipulate state over the lifetime of an object (e.g. open/read/close files) 
		- elements pass data to each other 
	- High - elements cooperate to perform exactly one task 

- Low cohesion - code isn't well organized 
	- Can't reuse one part without other stuff being bundled wit it
	- Hard to reuse and maintain 

- Goal: low coupling, high cohesion 

- Special case: what if 2 classes depend on each other? 

```C++
class A{
	int x;
	B y;
};

class B{
	char x;
	A y;
};
``` 

- Impossible: how big would A and B be? 

```C++
class B; //forward declaration of B

class A{
	int x;
	B *y; //compiler doesn't know what B is yet 
};

class B{
	char x;
	A *y;
};
```

- Sometimes one class **must** come before the other 

```C++
class C {...};

//need to know tthe size of C to construct D and E, so C must come first
class D:public C {...};

class E {C a};
``` 

- How should A and B be placed into modules? 
	- Modules must be compiled in dependancy order 
	- One modules can't forward declare another module, nor any item within that module 
	- Therefore, A and B must be in the same module 
	- Makes sense, since A and B are obviously tightly coupled 

Decoupling the Interface (MVC)*
-----
- Your primary program classes should not be printing things 

```C++
class ChessBoard{
	...
	cout << "Your move"; //bad design, inhibits code reuse 
};
```

- What if you want to reuse ChessBoard, but not have it communicate via cout? 
	- One solution; parameterize the class by a stream

```C++
class ChessBoard{
		istream &in;
		ostream &out;
	public:
		ChessBoard (istream &in, ostream &out): in {in}, out {out} {}
		...
		out << "Your move";
}
```

- Better, but what if we don't want to use streams at all? 
	- Your chessboard class should not be communicating with users at all 

- **Single Responsibility Principle** - "A class should have only one reason to change" 
	- i.e. if 2 or more distinct parts of the problem specification affect the same class, then the class is doing too much 
	- Each class should do only one job - game state **and** communication are 2 jobs 

- Better - communicate with ChessBoard via parameters/results/exceptions
	- Confine user communication to outside the game class 

- Should main do the talking then? 
	- No, it would be hard to reuse or replace code if it is in main
	- Should have a class to manage communication, that is separate from the game state class

Architecture: Model-View-Controller (MVC)
----
- Separate the distinct notions of the data or state ("model"), the presentation of the data ("view"), and control or manipulation of the data ("controller")

```mermaid
classDiagram

Model -- Controller
View -- Controller

class Model
class View
class Controller 
```

- Model - can have multiple views (e.g. text and graphics)
	- doesn't need to know their details
	- classic Observer pattern (or could communicate through the controller) 