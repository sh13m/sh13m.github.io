Q: What happens if encounter an error?  
[e.g.]
```C++
int i;
while (true) {
    cin >> i;
    if (cin.eof()) break;
    cout << i << endl;;
}
```

A: 
```C++
// 02-io: readInts.cc
...
    cin >> i;
    if (cin.fail()) break;  <-- fail() returns true for both EOF and error
...
```

Coercing
--------
- Can "coerce" std::cin into a boolean
```C++
cin >> i;
if (cin) cout << i << endl;
else break;
```
- Can apply operator ! to std::cin => equivalent to cin.fail()
```C++
while (true) {
    cin >> in;
    if (!cin) break;
    cout << i << endl
}
```
- Can coerce the modified istreamobject, returned by operator>>, into a bool
```C++
int i;
while(cin >> i) {
    cout << i << endl;
}
```

[Aside]
Note that both C and C++ can use << and >> for "bit-shifting"  

e.g. "a >> b" shifts a's bits b spots to the right  

    b10(21) = b2(10101); b10(21) >> b10(3) becomes b2(10) = b10(2)  
C++ however has "overloading"


Overloading
-----------
C++ allows multiple functions with the same name, but differ in number and
types of parameters (but doesn't care about return types)  

    => can determine statically (at compile time) which to call  
    => >> and << are overloaded

- If both inputs are ints, must be a bit-shift, which returns an int
- If one input is a stream (input or output) and other is an int (or so on),
  must be input/output and returns modified stream

e.g. I/O overloading
```C++
while (true) {
    if (!(cin >> i)) break;
    else cout << i << endl;
}

// reads ints until EOF, but gracefully handles errors
while (true) {
    if (!(cin >> i)) {          // true if either EOF or fail()
        if (cin.eof()) break;
        cin.clear();            // do first! reset state bits
        cin.ignore();           // reads and throws away 1 char 
    } else {
        cout << i << endl;
    }
}
```

Formatting
----------
- import \<iomanip> (part of std nampespace)
- Lets you format output e.g. setw, setfill, hex, dec, skipws, etc.
  e.g. cout << hex << 95; // prints "5f"
- State change via hex/dec affect global state
  => persists until you put it back via dec/hex

[General Rule]
Undo changes to global state when done


Strings
-------
- In C, strings are char pointers or arrays (maybe const)
- You need to explicitly manage memory
- Must terminate with '\0'
- Easy to make mistakes e.g. overwriting the '\0'
- In C++, can use C-style strings, but not recommended
```C++
  => import <string>;
     std::string
```
- Implemented as char array, but does all memory management for you
```
  e.g. string s1; // empty string
       string s2 = "Hello world";
       string s3{"Hello"};
       s2[0] = 'a';
       s1 = s2 + s3;
       s1 += "cat";
       if (s1 == s2) {...}
       if (s1 < "dog) {...}
       cin >> s1;
       cout << s2;
```
```C++
string line;
while (getline(cin, line)) { // everything on the line, up to newline, read into var. line
                                the newline is thrown away
    ...
}
```

Streams
-------
Streams are an "abstraction" for getting and putting information

1) file streams 
- import \<fstream>  
  => std::ifstream, std::ofstream  
  => works like istream, works like ostream
```C++
int main() {
    ifstream in{"input.txt"}; // opens "input.txt" in read-mode, fail bit is set if can't be found or read
    string word;
    while(in >> word) {
        // do something with word
    }
} // in is destroyed, closes the file
```
2) string streams : combination of string and (input/output) stream
- import \<sstream>  
```
  => std::ostringsteam : converts data to string  
     ostringstream oss = "initial value";  
     oss << 123 << ' ' << "hello worlds\n";
     ... oss.str() ...
```

```C++
// program to add command-line args that are ints
// together and output total
int main(int argc, char *argv[]) {
    int value, sum = 0;
    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (istringstream iss{arg}; iss >> value) sum += value;
        else cerr << "isn't an int" << endl;
    }
    cout << "total = " << sum << endl;
}
```