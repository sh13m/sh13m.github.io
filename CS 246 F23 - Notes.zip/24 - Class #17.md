# Class #17

Course: Computer Science (https://www.notion.so/Computer-Science-f9b44b2c4ee34218a87d90568f0868f2?pvs=21)
Confidence: Not Confident
Last Edited: November 9, 2023 6:40 PM

```cpp
// subject.cc
module;
#include <vector>
export module subject;
import observer;

export class Subject {
  std::vector<Observer*> observers;

 public:
  Subject();
  void attach(Observer *o);
  void detach(Observer *o);
  void notifyObservers();
  virtual ~Subject()=0;
};
```

```cpp
// observer.cc
export module observer;

export class Observer {
 public:
  virtual void notify() = 0;
  virtual ~Observer();
};
```

```cpp
// horserace.cc
module;
#include <fstream>
#include <string>
export module horserace;
import subject;

export class HorseRace: public Subject {
  std::fstream in;
  std::string lastWinner;

 public:
  HorseRace(std::string source);
  ~HorseRace();

  bool runRace(); // Returns true if a race was successfully run.

  std::string getState();
};
```

```cpp
// bettor.cc
export module bettor;
import <string>;
import observer;
import horserace;

export class Bettor: public Observer {
  HorseRace *subject;
  const std::string name;
  const std::string myHorse;

 public:
  Bettor(HorseRace *hr, std::string name, std::string horse);
  void notify() override;
  ~Bettor();
};
```

```cpp
// main.cc
import <iostream>;
import observer;
import horserace;
import bettor;

using namespace std;

int main(int argc, char **argv) {
  string raceData = "race.txt";
  if (argc > 1) {
    raceData = argv[1];
  }

  HorseRace hr{raceData};

  Bettor Larry{&hr, "Larry", "RunsLikeACow"};
  Bettor Moe{&hr, "Moe", "Molasses"};
  Bettor Curly{&hr, "Curly", "TurtlePower"};

  int count = 0;
  Bettor *Shemp;

  while(hr.runRace()) {
    if (count == 2)
      Shemp = new Bettor{&hr, "Shemp", "GreasedLightning"};
    if (count == 5) delete Shemp;
    hr.notifyObservers();
    ++count;
  }
}
```

```cpp
// race.txt
Molasses
RunsLikeACow
GreasedLightning
GreasedLightning
Molasses
FinishLine'sThatWay
```

### Decorator Design Pattern

CreateWindow

+scroll bar

+menu bar 

```cpp
Window *w1 = new BasicWindow;
w1 = new ScrollBar(w1);
w1 = new Menu(w1); // basic window with scrollbar and a menu bar
```

- decorator design pattern

→ allows us to enhance our object during runtime

→ Abstract Component: defines the interface and the operations that the object will provide

- decorators

→ abstract decorator inherits from AbstractComponent

→ decorator points to (has-a) component to decorator

→ all concrete decorators inherit from Abstract Decorator

→ every decorator is a Component

→ every decorator has a Component

![BF77D7C5-33EC-4C8E-9C6B-142E411B8290.jpeg](mdimg/BF77D7C5-33EC-4C8E-9C6B-142E411B8290.jpeg)

window w scrollbar w menu → window w scrollbar → plain window

- all inherit from abstract decorator
- window methods can be used polymorphically on all of them
    
    ![581E6CD0-CE8D-4443-BB4C-5434C3AE2BE1.jpeg](mdimg/581E6CD0-CE8D-4443-BB4C-5434C3AE2BE1.jpeg)
    

```cpp
// Pizza example
class Pizza {
	public:
		virtual float price () const = 0;
		virtual string desc() const = 0;
		virtual ~Pizza();
};

class CrustAndSauce : public Pizza {
	public:
		float price() const override { return 5.99; }
		string desc() const override { return "Pizza"; }
};

class Decorator : public Pizza {
	protected:
		Pizza* component;
	public:
		Decorator(Pizza *p) : component{p} {}
		~Decorator() { delete component; } // in our case, it makes sense to delete it
};

class StuffedCrust : public Decorator {
	public:
		StuffedCrust(Pizza *p) : Decorator{p} {}
		float price() const override {
			return component->price() + 2.69;
		}
		string desc() const override {
			return component->desc() + "with stuffed crust";
		}
};

class Topping : public Decorator {
	string theTopping;
	
	public:
		Topping(string topping, Pizza *p) : Decorator{p}, theTopping{topping} {}
		float price() const override {
			return component->price() + 0.75;
		}
		string desc() const override { 
			return component->desc() + "with " + theTopping;
		}
};
```

```cpp
// client.cc
Pizza *p1 = new CrustAndSauce;
p1 = new Topping{"cheese", p1};
p1 = new Topping{"mushrooms", p1};
p1 = new StuffedCrust(p1);

cout << p1->desc() << ' ' << p1->price() << endl;
delete p1;
```

UML:

- protected: #member
- static: member

```cpp
import <vector>;
import <iostream>;

using namespace std;

int main() {
	vector<int> v {0,2,4,6};

	// both work
	cout << v[3] << endl;
	cout << v.at(3) << endl;

	// outside the array
	cout << v[4] << endl; // produces undefined behaviour
	cout << v.at(4) << endl; // error "out_of_range"
}
```

- problem:

→ vector: detects the error, but does not know how to handle it

→ client: can handle the error, but can’t detect it

→ error is a non-local problem

- solution:

in C: 

→ functions return status code

→ set global variable error number

→ not great, creates awkward programming

→ programmers will ignore error-check (not ideal)

in C++:

→ when an error condition arises, functions raise an exception

→ by default, execution stops

→ we can write handlers for the exceptions

→ catch the exception and deal with them

```cpp

import <stdexcept>;

try {
	cout << v.at(4) << endl;
} 
catch (out_of_range r) {
	cout << "Range error: " << r.what() << endl;
}
// code will keep executing after the error
```

```cpp
void f() {
	throw out_of_range{"f"}; 
	// raises an exception and "f" is going to be returned by the method .what()
}

void g() { f(); }
void h() { g(); }

int main() {
	try {
		h();
	} 
	catch(out_of_range) {...}
}
```

main → h → g → f (x: out_of_range)

1. handler is found ← ← ← main is handling the exception
- we call this: unwind the stack
- control goes back in the call stack until a handler is found
- if no handler is found, the program terminates