System modelling
----------------
- describe classes, their relationships and constraints
- gives aid to designers and implementers  
  
Tool: class models from Unified Modeling language (UML)  
=> not tied to a specific implementation language

[e.g.]
```
|-----------------------------------------------|
| name        :   Vec                           |
| (minimum)                                     |
|-----------------------------------------------|
| datafields  :   - x : Integer                 |
|                 - y : Integer                 |
|-----------------------------------------------|
| methods     :   + mult(factor: Real, op: Vec) |
|-----------------------------------------------|

(-) private
(+) public
```

- generally, don't specificy: ctors, dtor, accessors, mutators
```
[A]-----[B]   // "association" line
```

Composition
-----------
- described as "owns-a" e.g. A owns B
  => A is "composed" (made up of) Bs
- no sharing; when A is destroyed, so are its B componets
  
[e.g.]
```
[Basis]◆-->2[Vec]
```
Implemented usually by composition 

[e.g.]
```C++
class Basis {Vec v1, v2; ...};
```
Q: in a composition, relationship, should copying be deep or shallow?

A: should be deep  
   => if big 5 implemented, relationship is ownership => composition


Aggregration
------------
- Usually described as "has a" relationship [A]<>-->[B] // A "has a" B
- [e.g.] car parts physically in warehouse, independent of paper (or electronic)
         catalogue

[e.g.]
```C++ 
class Duck {...};
class Pond {
  public:
  inline static const std::size_t MAX_DUCKS = 100;
  
  private:
  Duck *ducks[MAX_DUCKS];
  std::size_t numDucks = 0;
  ...
};
```
```
Pond
----
+ MAX_DUCKS: Integer = 100   // static, would be underlined on paper
- numDucks: Integer = 0

        ducks
[Pond]<>-->[Duck]
        0...MAX_DUCKS
```
Q: what if the multiplicity "```0...MAX_DUCKS```" is changed to "```*```" (0 or more)?

Aggregration implies shallow copies  
=> info is shared  
=> info not destroyed when containing object destroyed  
=> can be implemented by pointers, and in some cases, references  

Consider a Node class:
```C++
class Node {
  int data;
  Node *next = nullptr;
  public:
    // big 5
    ~Node() {delete next;}
    ...
    class List {... Node *theList; ...};
};
```
```
__________________ next
|Node            |<------|
|----------------| 0...1 |
|- data: Integer |◆------|
|________________|
         ^
______   | theList
|List|◆-| 0...1
|----|
```

Q: What if class model was: ```[List]◆-->*[Node]```?

A: suggests List may need to iterate over nodes to free them
