
- Recall: 

```C++
using Enemy = variant <Turtle, Bullet>;
Enemy e {Turtle{}};

//Discriminating the value

if (holds_alternative <Turtle>(e)){
	cout << "Turtle";
}
else ...

//Extracting the value

try {
	Turtle t = get<Turtle>(e);
	//use t ...
}
catch (bad_variant_access f){
	//if t isn't a Turtle
}
```

- A variant is like a union, but type-safe
	- Attempting to store as one type and fetch as another will throw
	- If a variant is left uninitialized, the first option in the variant is default-constructed to initialize the variant
	- Compiler error if the first option is not default constructible

- Options:
1. Make the first option a type that has a default ctor 
2. Don't leave your variant uninitialized 
3. Use std::monostate as the first option - "dummy" type that can be used as a default
	- This may be used to create an "optional" type:

```C++
variant<monostate, T> //= "T or nothing"

//also: std::optional<T>
```

**How Virtual Methods Work**

```C++
class Vec {
	int x, y;
	void f() {...}
};

class Vec2 {
	int x, y;
	virtual void f() {...}
};

//What's the difference?

Vec v {1, 2}; //do v and w look the same in memory?
Vec2 w {1, 2};

cout << sizeof(v) << ' ' << sizeof(w); //outputs 8 16
```

- First note: 8 is space for 2 ints - no space for the f method 
	- Compiler turns methods into ordinary functions and stores them separately from objects 
- Recall: 

```C++
			   Book
Book *pb = new Text
			   Comic

					 <Book>
auto pb = make_unique<Text>(...);
					 <Comic>

pb->isHeavy();
```

- isHeavy is virtual - choice of which version to run is based on the type of the actual object (which the compiler won't know in advance) 
	- Choice must be made at runtime 

- For each class with virtual methods, the compiler creates a table of function pointers (the vtable) 

```C++
class C{
	int x, y;
	virtual void f();
	virtual void g();
	void h();
	virtual void ~C();
};
```

```mermaid
classDiagram
class vtable{
	"C"
	f
	g
	~C
}

vtable --|> C - f
class C - f

vtable --|> C - g
class C - g

vtable --|> C dtor
class C dtor

C c vptr --|> vtable
class C c vptr{
	x
	y
}

C d vptr --|> vtable
class C d vptr{
	x
	y
}
```

- C objects have an extra pointer (the vptr) that points to C's vtable:

- Calling a virtual method (at runtime):
	- follow vptr to vtable
	- fetch ptr to actual method from table
	- follow the function ptr and call the function 
- Virtual function calls incur a small overhead cost in time 

- Also, having at least 1 virtual function adds a vpointer to the object 
	- classes with no virtual functions produce smaller objects than if some were virtual (space cost) 
- Concretely, how is an object laid out? Compiler dependant 

- Why did we put the vptr first in the object and not somewhere else (e.g. last)? 

```C++
class A {
	int a, c;
	virtual void f();
};

class B: public A {
	int b, d;
};
```

```mermaid
classDiagram
class A{
	vptr
	a
	c
}

class B{
	vptr
	a
	c
	b
	d
}
```

- So a ptr to B looks like a ptr to A (if you ignore the last 2 fields) 
- So we know where the vptr is without knowing what kind of object we have 

**Multiple Inheritance** 

- A class can inherit from more than one class 

```C++
class A {
public:
	int a;
};

class B {
public:
	int b;
};

class C: public A, public C{
	void f() {
		cout << a << ' ' << b;
	}
};
```

```mermaid 
classDiagram

class A
class B

C --|> A
C --|> B
class C
```

- Challenges: suppose B and C inherit from A

```mermaid 
classDiagram

class A1 {
	+a
}

class A2 {
	+a
}

B --|> A1
class B {
	+b
}

C --|> A2
class C {
	+c
}

D --|> B
D --|> C
class D {
	+d
}
```

```C++
class D: public B, public C {
	public:
		int d;
};

D dobj;
dobj.a;
```

- Which a is this?
	- Ambiguous - compiler error
- Need to specify - dobj.B::a or dobj.C::a

- But if B and C inherit from A, should there be one A part of D or 2? 
	- Should B::a and C::a be the same or different?

```mermaid 
classDiagram

class A

B --|> A
class B

C --|> A
class C

D --|> B
D --|> C
class D
```

- Make A a virtual base class - virtual inheritance 

```C++
class B: virtual public A {...}
class C: virtual public A {...}
```

- E.g. IO stream hierarchy 

```mermaid 
classDiagram

class ios_base

ios --|> ios_base
class ios

istream --|> ios
class istream

ostream --|> ios
class ostream

iostream --|> istream
iostream --|> ostream
class iostream

fstream --|> iostream
class fstream

stringstream --|> iostream
class stringstream
```

- How would this be laid out in memory?

- Distance from a class to it's parent is not constant - depends on the runtime type of the obj
	- Solution: distance to the parent obj is stored in the vtable

- Diagram doesn't look like all of A, B, C, D simultaneously 
	- but slices of it do look like A ,B, C, D
- ptr assignment among A, B, C, D changes the addr stored in the ptr
	- Static/dynamic cast also do this, reinterpret_cast does not

```C++
D *d = new D;
A *a = d; //changes the address
```
