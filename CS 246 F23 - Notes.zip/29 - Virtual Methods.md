How Virtual Methods Work
--

consider:
```C++
class Vec {
    int x, y;
    
    public:
    void f();
};

class Vec2 {
    int x, y;

    public:
    virtual void g();
};

int main() {
    Vec v;
    Vec2 w;
    cout << sizeof(int) << " " << sizeof(v) << " " << sizeof(w) << endl;
}
```

int => 4 bytes  
sizeof(v) = 2 x 4 = 8 bytes since f store with other stand-alone functions  
sizeof(w) = 16 bytes = 2 x 4 + (8) <- "vptr" to "vtable"

- all object of type Vec2 have the same vptr value  
  => at run-time, follow vptr to vtable, where look up

Note: C++ standard doesn't specify use of vtables, but it's the commonest approach

vtable = table of function pointers
