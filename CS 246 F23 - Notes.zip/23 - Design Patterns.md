Design Patterns
---------------
Principle: program to interface, not implementation  
=> polymorphic, so working with pointers to base (or abstract base) classes  
=> methods are virtual  
=> will swap out (concrete) subclasses at either compile-time or run-time
   to get different behaviours


Iterator design pattern
-----------------------
Abstract base class, AbstractIterator,

[e.g.] 
```
AbstractIterator <italics>
-------------------------
+ move(): AbstractIterator <italics>
+ notEqual(AbstractIterator it): Boolean <italics>
+ get(): Integer <italics>
```
```C++
class AbstractIterator {
    public:
    virtual ~AbstractIterator() = 0;
    virtual AbstractIterator & move() = 0;
    virtual bool notEqual(const AbstractIterator &other) const = 0;
    virtual int get() const = 0;
};
```
=> 
```C++
class List {
    ...
    public:
    class Iterator: public AbstractIterator {
        ...
        public:
        // implement pure virtual methods
    };
    ...
};
```
SIDE NOTE: could template AbstractIterator

Allows us to write:
```C++
void foreach(AbstractIterator &b, AbstractIterator &e, void(*f)(int)) {
    while (b.notEqual(e)) {
        f(b.get());
        b.move();
    }
}
```

Observer design pattern
-----------------------
- also known as "Publish-Subscribe"
- classic example: spreadsheet provides view of cells in sheet and chart
                   if make change, both update
- e.g. social media notifications from accounts you follow
- "push" or "pull" models for notifications

```
Subject <italics>   *<>------------->  Observer <italics>
-----------------                   *  ------------------
+ attach(Observer): void               + notify(): void <italics>
+ detach(Observer): void
+ notifyObservers(): void                     ^
                                              -
^                                             |
-                                          *  Concrete Observer
|                  |-----------------------<> -----------------
Concrete Subject <-|                          + notify(): void <italics>
----------------  *
+ getState(): ?
```

Decorator design pattern
------------------------
- lets us dynamically change abilities and/or attributes at run-time (dynamically)
- classic example: windows drawing system, title bar, scroll bar, max/min/resize
  appear and disappear dynamically
```
Pizza <italics>             <|---------- Decorator <italics>
---------------                          -------------------
+ cost(): Double <italics>  <---------<> 
+ desc(): String <italics>      next

^
-                                                 ^              ^
|                                                 -              -
                                                  |              |   
Cust with Sauce [thing being decorated]           Stuffed Crust  Topping
---------------
```