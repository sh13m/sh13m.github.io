Casting
--
1) reinterpret_cast: used for "weird" type conversions implementation-dependent; usually results in undefined behaviour -> unsafe

```C++
Student s;
Turtle *tptr = reinterpret_cast<Turtle*>(&s);
```
2) static_cast: "sensible casts" with well-defined semantics

```C++
double d = 3.14159;
void f(int i);
void f(doube d);
f(static_cast<int>(d)); // takes f with int
Text *t;
Book *b = new Text{...};
t = static_cast<Text*>(b);
```
=> undefined behaviour if fails

3) dynamic_cast: conversion may or may not succeed

```C++
Book *bptr = new Comic{...};
Comic *cptr = dynamic_cast<comic*>(bptr);
Text *tptr = dynamic_cast<Text*>(bptr); // fails tptr = nullptr
Book &bref = *bptr;
Comic &cref = dynamic_cast<Comic&>(bref);
Text &tref = dynamic_cast<Text&>(bref); // raises std::bad_cast
```
can cast std::shared_ptr eg static_pointer_cast, dynamic_pointer_cast, etc
Note: dynamic_cast on classes only works for classes with at least 1 virtual method 

=> now can solve polymorphic move/copy assignmen!

```C++
Text & Text::operator=(const Book &other) { // virtual
	const Text &oref = dynamic_cast<Text&>(other);
	if (this == &oref) return *this;
	Book::operator=(other);
	topic = oref.topics;
	return *this;
}
```

4) const_cast: addss or removes "constness" from a variable
	=> be careful when removing const since implicit assertion is that it won't be changed

Q: is the use of (static or) dynamic cast a sign of poor design?

A: consider a method designed to output Run-Time Type Information (RTTI)

```C++
void whatIsIt(shared_ptr<Book> b) {
	if (dynamic_pointer_cast<Comic>(b)) {
		cout << "Comic" << endl;
	} else if {dynamic_pointer_cast<Text>(b)} {
		cout << "Text" << endl;
	} else if {dynamic_pointer_cast<Book>(b)} {
		cout << "Book" << endl;
	} else {
		cout << "Unknown" << endl;
	}
}
```

- doesn't let us add subclasses easily  
=> add more code to deal with new classes  
=> update all casts  
=> easy to miss cases

Constrast o Text copy assignment 
```C++
Text & Text::operator=(const Book &o) {
	Text &tref = dynamic_cast<Text&>(o);
	Book::operator=(o);
	...
}
```
=> only casts to Text so unaffected by adding subclassses  
can re-write whatIsIt to better use polymorphism

=> all classes implement virtual identify()

```C++
void whatIsIt(Book *b) {
	if (b) cout << b->identify() << endl;
	else cout << "Unknown" << endl;
}
```

Q: when is inheritance a good design approach?

A: have 

1) infinite subclasses
2) they have same interfaces

makes adding a new class easy

Q: is inheritance the right approach for a small finite # of classes with differnt interfaces?

A: No, just make necessary changes if/when occurs

- C approach would be 'tagged union'
- C++ introduces type-safe std::variant \<variant>
 
=> specify comma-separated list of types  
=> use "using" to create a type alias similar to C's typedef

eg.
```C++
using Enemy = variant<Turtle, Bullet>; // can only be a Turtle or a Bullet
Enemy e{Turtle{}};
if (holds_alternative<Turtle>(e)) {
	cout << "Turtle";
}

try{
	Turtle t = get<Turtle>(e);
	// use t as a Turtle
} catch (std::bad_variant_access &) {

}
```

Q: what happens if write: ```Enemy f;``` ?

A: picks first type from variant list, but it must have a default ctor => compiler error if not


Options:

1) put type with default ctor first
2) initialize variant
3) Use std::monostatic as a optional dummy type

eg. 
```C++
variant<monostate, T> // T or "nothing"
```

(also std::optional\<T>)
