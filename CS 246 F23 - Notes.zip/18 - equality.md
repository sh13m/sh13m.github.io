Equality Revisited
------------------
Consider adding a length data field to List
- either need to count each time calculate size, or keep track as list 
  grows/shrinks (O(n) vs O(1))
- now lets us "cut short" equality test since if lengths are different, lists
  can't possibly be equal
- if write either ```operator==``` (or ```operator!=```), compiler will use that to
  implement the other  
  (remember, otherwise <=> is used to implement all 6)

[e.g.]
```C++
class List {
    ...
    public:
        auto operator<=>(const List &other) const {
            if (!theList && !other.theList) return std::strong_order::equal;
            if (!theList) return std::strong_order::less;
            if (!other.theList) return std::strong_order::greater;

            return *theList <=> *other.theList; // Node::<=>
        }
        bool operator==(const List &other) const {
            if (length != other.length) return false;
            return (*this <=> other) == 0;
        }
        
};

List myL1, myL2;
...
if (myL1 <=> myL2) ...
```
