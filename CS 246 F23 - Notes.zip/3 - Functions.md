Overloading Revisited
---------------------
Already saw << and >> as examples of overloading i.e. either bit-shifting
or input/output, based on context  
=> compiler determines which to call "statically" i.e. at compile time

[C (no overloading)]
```C
int negInt(int a) {
    return -a;
}
bool negBool(bool b){
    return !b;
}
```
[C++]
```C++
int neg(int a) {
    return -a;
}
bool neg(bool b) {
    return !b;
}
```
- In C++, can have same function name so long as functions have different
  number and/or typesof parameters  
  => doesn't care about return types
- Can have overloading by having default function parameters

```C++
void printSuite(string file="sample.txt") {
    ifstream in{file};
    string word;
    while (in >> word) {
        cout << word << endl;
    }
}

int main(int argc, char *argv[]) {
    if (argc == 1) printSuite(); // passes in "sample.txt"
    // uniform initialization syntax
    else printSuite(string{argv[1]});
    // else {string arg = argv[1]; printSuite(arg);}
}
```
- Default parameters must be at the end of the parameter list
- On caller's behalf, compiler passes non-default values and generates the
  default values
- Callee knows required number of parameters and will read them off the
  run-time stack  
  => if values are missing, callee reads whatever is in subsequent memory
     locations  
  => probably garbage!  
  => default values must be specified in the interface/declarations, not in
     implementation

```C++
// interface
void printSuite(std::string name="sample.txt");

// implementation
void print Suite(string name) {
    ...
}
```
- especially important when we do separate compilation


Structs
-------
```C++
struct Node {
    int value;
    Node *next
};

Node *ptr = nullptr
Node n{1, nullptr}
Node m{2, &n}
```

Q: Why is the following wrong?
```C++
struct Node {
    int value;
    Node next; // [Node] is an incomplete type definition!
}; // completes the type def, but too late
```
=> change "Node" to "Node *" to fix


Constants
---------
- Use them wherever sensible in this course
- Don't use #define since not type safe!
- Has to be initialized when declared

e.g.
```C++ 
const int MAX_SIZE = 10;
Node n{n, nullptr};
const Node m = n; // m in "immutable"
```

Paramater Passing
-----------------
e.g. 
```C++
    void inc(int n) {++n;}
    ...
    int val = 5;
    inc(val);
    cout << val << endl; // outputs 5!
```
=> passed by value, therefore made a copy on the run-time stack
   and changed the copy, not the original

- C/C++ can pass by pointer
```C++
void inc(int *n) {++(*n);}
...
inc(&val);
```
But remember: cin >> val; cout << val;  
never took addresses => C++ has references!
