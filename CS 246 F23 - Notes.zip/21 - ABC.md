Pure virtual methods and abstract base classes (ABCs)
-----------------------------------------------------
An abstract base class cannot be instantiated  
=> provides and interface framework, maybe some info to be inherited  
=> can have inheritance levels of ABCs  
=> child class that can be instantiated is called "concrete" subclass

- an ABC requires at least 1 "pure vitrual" method

[e.g.]
```C++
class Student {
    ...
    public:
    virtual double calcFees() = 0; <- makes it pure virtual
    ...
};
```

- if there's no good choice for what method to make pure vitrual, use the dtor
  
WARNING!! must still implement the dtor, though 

[e.g.]
```C++
class DigitalMedia {
    public:
    ~DigitalMedia() = 0;    // still implement in .cc
    ...
};
```
- if a subclass doesn't implement all pure virtual (note: parent must implement
  it's own pure vitual dtor), then it itself is an ABC and can't be instantiated

UML class model notation:
- class name of ABC is either italicized or decorated with "{abstract}"
- pure vitual methods are italicized


Inheritance and move/copy
-------------------------
- we'll use a simple inheritance hierachy to illustrate problems and solutions  
  => should be able to integrate with more complex scenario where Big 5 do deep
     copy
- focus will often be on copy for simplicity, but issues also apply to move
- consider:
```C++
class Book {
    ...
    public:
    // Implement Big 5
};

class Text : public Book {
    string topic;
    public:
    // Doesn't implement Big 5
};
```
[e.g.] 
```C++
Text t1 {...};
Text t2 {...};
t1 = t2;
```
Q: What happens when run ```Text::operator=``` ?

A: Runs Book::operator=, leaving topic then performs field-by-field copy

Q: What happens if attempt assignment polymorphism call?

[e.g.]
```C++
Book *bp1 = &t1, *bp2 = &t2;
*bp1 = *bp2;
```
A: Runs Book::operator=. set at compile time, since not vitual  
   => copies everything but topic  
   => this problem is called "partial assignment"

Start by writing Big 5 for Text: 

[e.g.]
```C++
Text::Text(const Text &other) : Book{other}, topic{other.topic} {}

Text::Text(Text &&other) : Book{std::move(other)}, topic{std::move(other.topic)} {} // std::move forces it to be treated as rvalue

Text & Text::operator=(const Text &other) {
    // should add either self-assignment check or copy-swap idiom code
    // but focus is on inheritance
    Book::operator=(other); // copies Book portion
    topic = other.topic;
    return *this;
}

Text & Text::operator=(Text &&other) {
    Book::operator=(std::move(other)); // invoke move assignment
    topic = std::move(other.topic);
    return *this;
}
```

- now have big 5 for sub classes; how do I get them called if I'm using a (Book *)  
  => ctors can't  declared to be virtual (semantically meaningless), but can use
     Factory Method design pattern or vitual constuctor idiom (eg. virtual clone method)  
  => can make operator= virtual in parent class; but this means that the parameter
     MUST be a Book  
  => subclasses can only override if their parameter is also a Book  
    - can return a Text& or Comic& since compiler only sees that they are Books
  
[e.g.]
```C++
class Book {
    ...
    public:
    ...
    virtual Book &operator=(const Book &o);
    ...
};

class Text : public book {
    ...
    public:
    ...
    virtual Text &operator=(const Book &o) override;
    ...
};
```

Unfortunately, now have enable "mixed assignment" 

```Book b{...}; Textt{...}; Comic c{...};```
```C++
c = b; // legal, but not great
t = c; // legal, but siblic = is worse !
```

General solution: (one possible approach until see exceptions and casting)  
                  => make all super classes abstract

```C++
class AbstractBook {
    string author, title;
    int numpages;
    
    protected:
    Book &operator=(const AbstractBook &o);
    public:
    virtual ~AbstractBook() = 0;
    ...
};
AbstractBook::~AbstractBook() {}

class Comic : public AbstractBook {
    ...
    public:
    ...
    Comic &operator=(const Comic &o) {
        AbstractBook::operator=(o);
        hero = other.hero;
        return *this;
    }
    ...
};
```
=> polymorphic assignment through pointers/references doesn't work currently  
=> but compiler prevents partial- and mixed-assignment since AbstractBook is an
   ABC, can't instantiate it so: AbstractBook a{...} is illegal  
```C++
Text t{...}; Book b{...}; Comic c{...};
t = b; // illegal
c = t; // illegal
```
