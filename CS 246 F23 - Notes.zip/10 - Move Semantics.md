Move Semantics
--------------
- Remember that an "lvalue" has a known accessible address while a
  "lvalue reference" is equivalent to an automatically dereferenced constant
  pointer
- Consider the Node class with defined copy ops i.e. ctor and =

Consider the following function:
```C++
Node oddOrEven() {
    Node odd{1, new Node{3, new Node{5, nullptr}}};
    Node even{2, new Node{4, new Node{6, nullptr}}};
    char c;
    cin >> c;
    if (c == '0') return odd;
    return even;
}

Node n = oddOrEven(); // return value passed to copy ctor
```
=> by end of function oddOrEven, both objects odd and even are destroyed  
=> object returned had to be deep-copied onto run-time stack so available
   to n's copy ctor  
=> then, deep-copied by copy ctor into n  

Trick: recognize that parameter "other" in Node's copy ctor is actually bound
       to an "rvalue" that will be destroyed as soon as ctor finishes  
       => just steal rather than copy  
       => need to be able to tell when have an "rvalue reference"  
       => &&

Nove ctor for Node:
```C++
Node::Node(Node &&other) : data{other.data}, next{other.next} 
                           {other.next = nullptr;}


// <utility>
Node & Node::operator=(Node &&other) {
    using std::swap;
    swap(data, other.data);
    swap(next, other.next);
    return *this;
}
```
Version 2:
```C++
    Node temp{std::move(*this)}; // move ctor, moves *this into temp
    data = other.data
    next = other.next;
    other.next = nullptr;
    return *this;
```

Note: if don't define move ctor/assignment operator, copy versions used instead  
      => if define move operator and parameter an rvalue, all copy operations
         replaced by move operations