Three points of view:
---------------------

1) Programmer: Write correct, quality code and minimize chance of bugs
2) Compiler: How are constructs implemented and supported
3) Software design: How can OOP help us structure systems, SE concepts


Comparing C/C++ "Hello world"
-----------------------------

[C]
```C
#include <stdio.h>
int main() { // can be void    
    printf("Hello world\n");
    return 0;
}
```
[C++]
```C++
import <iostream>;
int main() { // cannot be void
    std::cout << "hello world" << std::endl;
    return 0; // default behaviour, can be omitted
}
```

std::cout    
- stdout, global object, part of std namespace  

```operator<<``` 
- output operator  
- equiv. ```<<``` 

std::endl   
- combo of '\n' and buffer flush request  

return 0;    
- default return value to shell ($?)  
- can be ommitted in functions

SIDE NOTE: exit() is a C function, won't clean up programs properly once have declared objects


I/O Streams
-----------
```
standard output  /  stdout  ->  std::cout   ‾|
standard error   /  stderr  ->  std::cerr    | GLOBAL OBJECTS
standard input   /  stdin   ->  std::cin    _|

Mnemonics:
Output  ->  goes into the stream                    e.g.    stderr << "error"
Input   ->  goes from the stream into variables     e.g.    int x, y;
                                                            std:cin >> x >> y;
```

Compiler Terms
--------------

```
g++-11          g++ compiler, version 11
-std=c++20      C++ standard 20 (2020)
-Wall           Show all warnings
-g              Saves extra symbol table info for gdb/valgrind
-fmodules-ts    Turn on module support
-x              language
-c++-system-header
```

SAVE TIME
---------

```c++
import <iostream>;
using namespace std;

std::cout -> cout
```
[WARNING: DO NOT USE THIS IN HEADER FILES, VERY BAD FORM]


Terminal Thing
--------------
```
ctrl-d       simulates stream state for EOF
ctrl-c       kills the program, use with caution (emergency situations)


Q: How does operator>> know when to stop?
A: Depends on the variable type

char    ->  reads 1 byte
int     ->  stops at white space or non-int type
```

CODE: Read and output ints until EOF
------------------------------------
```C++
import <iostream>;
using namespace std;

int main() {
    int value;
    while (true) {
        cin >> value;   // must try reading before testing
        if (cin.eof()) break;
        cout << value << endl;
    }
}
```

Q: How could reading an int fail?
- encounter EOF
- attempt to read non-int value
- overflow/underflow


A: Ask cin.fail(), returns true if EOF or read fail
