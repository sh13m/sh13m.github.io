Copy/Move Elision
-----------------
- C++20 standard requires that move/copy operations be replaced by an
  "in-place" byte-wise copy even if execution of ctor had side-effects and
  removal of execution changes behaviour

Consider Vec with move/copy ctors defined
```C++
Vec makeVec() {return {0,1};} // rvalue returned
Vec v1 = makeVec();
Vec v2;
...
v2 = makeVec();
```
If want to see code without elision, compile with -std=c++17 and -fno-elide-constructors

Only need to be aware that  elision happens, not the rules.

- Remember the Rule of 5 (or Big 5)
    - destructor, move/copy ctors, move/copy assignment  
=> if providing one of these, should consider whether or not all 5 need
   to be provided

- not all classes need custom big 5 ops i.e. compiler-provided versions are enough
- if managing resources (e.g. heap memory, files, etc.) may need some or all of these
