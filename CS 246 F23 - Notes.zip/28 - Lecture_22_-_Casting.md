Casting
--

- In C:

```C
Node n;
int *ip = (int *)&n; //cast - forces C to treat a Node* as an int* 
```

- C-style casts should be avoided in C++ 
- If you must cast, use a C++-style cast:
1. static_cast - "sensible casts" or casts with well-defined semantics 
	- e.g. double->int

```C++
double d;
void f(int x);
void f(double d);
f(static_cast<int>(d));
```

- e.g. superclass ptr -> subclass ptr

```C++
Book *b = new Text{...};
Text *t = static_cast<Text *>(b);
```

- You are taking responsibility that b actually points to a Text

2. reinterpret_cast - unsafe, implementation-specific, "weird" casts

```C++
Student s;
Turtle *t = reinterpret_cast<Turtle*>(&s);
```

3. const_cast - for converting between const and non-const
	- the only C++ cast that can "cast away const" 

```C++
void g(int *p); //suppose we know that under the circumstances in which
				//f operates, g won't moderate *p 

void f(const int *p){
	...
	g(const.cast<int *>(p));
	...
}
```

4. dynamic_cast - Is it safe to convert a `Book *` to a `Text *`?

```C++
Book *pb = ...;
static_cast <Text*>(pb)->getTopic(); //safe?
```

- Depends on what pb actually points to
- Better to do a tentative cast - try it and see if it succeeds 

```C++
Text *pt = dynamic_cast<Text *>(pb);
```

- If the cast works (`*pb` really is a Text, or a subclass of Text), pt points to the object
- If not - pt will be nullptr 

```C++
if (pt) cout << pt.getTopic();
else cout << "Not a Text";
```

- These are operations on raw pointers, can we do them on smart pointers?
	- Yes - static_pointer_cast, etc.
	- Cast shared_ptrs to shared_ptrs 
- Dynamic casting also works with refs:

```C++
Text t {...};
Book &b = t;
Text &t2 = dynamic_cast<Text &>(b);
```

- If b "points to" a Text, then t2 is a ref to the same Text
- If not...? (no such thing as a null reference)
	- Throws std::bad_cast 

- Note: dynamic casting only works on classes with at least one virtual method

- Dynamic reference casting offers a possible solution to the polymorphic assignment problem: 

```C++
Text &Text::operator=(const Book &other){ //virtual
	const Text &tother = dynamic_cast<const Text &>(other);
	Book::operator = (other); //throws if other is not a Text 
	topic = tother.topic; 
	return *this;
}
```

- Is dynamic casting good style?
	- Can use dynamic casting to make decisions based on an object's runtime type information (RTTI)

```C++
void whatIsIt(Book *b){
	if (dynamic_cast<Comic *>(b)) cout << "Comic";
	else if (dynamic_cast<Text *>(b)) cout << "Text";
	else if (b) cout << "Book";
	else cout << "Nothing";
}
```

- Code like this is **tightly coupled** to the Book hierarchy, and may indicate bad design 
	- What if you create a new kind of Book? 
		- whatIsIt doesn't work anymore until you add a clause for the new Book type 
		- Must do this wherever you are dynamic casting 
	- Better: use a virtual method 

- Note: Text::operator= doesn't have this problem (only need to compare with your own type, not all the types in the hierarchy) 
- So dynamic casting isn't always bad design
	- How can we fix whatIsIt?

```C++
class Book{
	...
	virtual void identify() {cout << "Book";}
};

void whatIsIt(Book *b){
	if (b) b->identify();
	else cout << "Nothing";
}
```

- Works by having an interface function that is uniform across all Book types 
	- What if the interface isn't uniform across the hierarchy? 

- Inheritance and virtual methods work well when 
	- there is an unlimited number of potential specializations (subclasses) or a basic abstraction 
	- each following the same interface 
 - But what if we have the opposite case?
	 - small number of specializations, all known in advance, unlikely to change 
	 - with different interfaces

- In the first case - new subclass -> no effort at all
- In the second case - new subclass -> rework existing code to accommodate the new interface, but that's fine because you aren't expecting to add new subclasses (or are expecting to pit in that effort) 

```C++
class Turtle: public Enemy{
	void stealShell();
};

class Bullter: public Enemy{
	void deflect();	
};
```

- Interfaces not uniform - a new Enemy type is going to mean a new interface and unavoidable work 
	- So we could regard the set of Enemy classes as fixed, and maybe dynamic casting is justified 
	- However, in this case, maybe inheritance is the wrong tool 

- If you know that Enemy will only be a Turtle or a Bullet, and you accept the work that comes with adding new Enemy types, then consider:

```C++
import <variant>;

typedef variant<Turtle, Bullet> Enemy;

//equiv:

using Enemy = variant <Turtle, Bullet>; //an Enemy is a Turtle or a Bullet 

Enemy e {Turtle{}}; //or Bullet{}

if (holds.alternative<Turtle>(e)){
	cout << "Turtle";
} else 	{
	cout << "Bullet";
}
```

