Comparison
----------
[Compiler doesn't prove operator== or operator!= for free]

- in C, can compare (const char*) using strcmp/strncmp
```C
int ret == strcmp("hello", "help");
if ret == 0 => equal
        < 0 => s1 < s2
        > 0 => s1 > s2
```
- naive approach (pre-C++20)
```C
string s1{"hello"}, s2{"help"};
if (s1 == s1) { 
    ...
} else if (s1 < s2) { 
    ...
} else {
    ...
}
```
C++20 introduces operator<=> that returns std::strong_ordering  
=> import/include \<compare>
```C++
std::strong_ordering res = s1 <=> s2;
if (res == 0) cout << "s1 == s2";
else if (res < 0) cout << "s1 < s2";
else cout << "s1 > S2"
```
=> if setup correctly, <=> buys you all 6 comparison operators  
=> can use type deduduction  

[e.g.] ```auto res = s1 <=> s2;```

Q: how to implement for Vec?

A:
```C++
struct Vec {
    auto operator<=>(const Vec &other) const {
        auto n = x <=> other.x;
        return n == 0 ? (y <=> other.y) : n;
    }
};

Vec v1, v2;
... v1 <=> v2;
```

[e.g.]
```C++
Vec v1{1, 0}, v2{1, 0}
v1 <= v2 is equivalent to (v1 <=> v2) <= 0
```

Q: How do we get the compiler to provide <=>?

A:
```C++
struct Vec {
    int x, y;
    // tells compiler to generate <=>
    // performs field-by-field call to <=>
    // stops when != or runs out of fields
    auto operator<=>(const Vec &v) = default;
};
```

Q: when doesn't this work?

A: For example
```C++
struct Node {
    int data;
    Node *next; // comparing addresses in pointers isn't helpful
};
```
```
2 singly-linked lists are equal iff all data values are same
p -> 1 -> 2 -> 3 -> "
q -> 1 -> 4 -> 3 -> "       q > p ? True
s -> 1 -> "                 s < p ? True
t -> 5 -> "                 s < t ? True
```
```C++
Struct Node {
    ...
    auto operator<=>(const Node &other) const {
        auto n = data <=> other.data;
        if (n != 0) return n;
        if (!next && !other.next) return n; // both nullptrs
        if (!next) return std::strong_ordering less;
        if (!other.next) return std::strong_ordering greater;
        return (*next <=> *other.next);
    }
};
```
