Copy Assignment Operator
------------------------
- Default version provided by compiler only does "shallow" copy  
  => in any data fields are objects, call their copy assignment operator

[e.g.]
```C++
struct Student{
    string name;
    int assns, mt, final;
};

Student s1{"Stuart", 99, 98, 100};
Student s2;
...
s2 = s1;            // copy assignment operator
Student s3 = s1;    // copy ctor

struct Node{
  ...
  Node &operator=(const Node &other);
  ...  
};

Node n1{1, nullptr};
Node n2{3, nullptr};
n1 = n2;

// MANY PROBLEMS
Node & Node::operator=(const Node &other) {
    data = other.data;
    next = (other.next == nullptr? nullptr : new Node{*(other.next)});
    return *this;
}
```
Q: what if n1.next != nullptr?

A: memory leak!
- need to free this->next, but order of operation matters since if new fails
  (ran out of heap memory) we immediately return to caller (need exceptions
  to explain why)  
  => ensure delete is after deep copy 

```C++
// ONE MORE THING STILL WRONG WITH THIS
Node & Node::operator=(...) {
    Node *temp = next;
    next = (other.next == nullptr? nullptr : new Node{*other.next});
    // note that "next is only changed iff deep-copy succeeded
    data = other.data;
    delete temp;
    return *this;
}
```
Q: what happens in:
  ```C++
    Node n{...};
    ...
    n = n;  // self assignment
  ```
?

A: Some implementations of copy assignment will destroy original data and can't
   recover  

[e.g.]
```C++
...
delete next;
next = (other.next ...);
```
"n = n;" is unlikely, but if have pointers p and q that happen to have the same
address *p = *q; or have an array of (Node *) and indices i and j happen to have
same address ```e.g. *arr[i] = *arr[j]```

=> add a "self assignment" test
```C++
Node & Node::operator=(const Node &other){
    if (this == &other) return *this;
    Node *temp = next;
    next = ...
    delete temp;
    data = other.data;
    return *this;
}
```
\<utility> std::swap  

Alternative Approach: copy-swap idiom  
idiom: programming language level solution to a common problem  
=> use copy ctor  
```C++
Node & Node::operator=(const Node &other) {
    Node temp{other};   // deep copy by copy ctor
    std::swap(data, other.data);
    std::swap(next, temp.next);
    return *this;
} // temp destroyed here
```
