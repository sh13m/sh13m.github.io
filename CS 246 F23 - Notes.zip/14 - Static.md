"static" in classes
-------------------
- declaring a data field "static" implies there is only 1 instance per class,
  and all objects of that class share it

[e.g.]
```C++
struct Student {
    inline static int numObjs = 0;
    int assns, mt, final;
    Student(...) : /* MIL */ : {numObjs++;}
    ~Student() {--numObjs;}
};
```
- if need to access static data before any objects created (and not public),
  need a static method

[e.g.] 
```C++
cout << Student::numObjs << endl; // outputs 0
Student::foo();
{Student s; s.foo()}; // outputs 1
Student::foo() ; // 0 out of scope


static void foo() {cout << numObjs << endl;}
```
