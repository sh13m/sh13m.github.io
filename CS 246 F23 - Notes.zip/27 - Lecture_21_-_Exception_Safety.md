
Exception Safety
---
- What is exception safety?
	- It isn't:
		- That exceptions never happen
		- All exceptions get handled 
	- It is:
		- After an exception has been handled, the program is not left in a broken/unusable state

- Specifically, 3 levels of exn safety for a function f:
1. Basic guarantee - if an exn occurs, the program will be in some valid state - nothing is leaked, no corrupted data structures, all class invariants maintained 
2. Strong guarantee - if an exception is raised while executing f, the state of the program will be as if f had not been called 
3. No-throw guarantee - f will never throw or propagate an exn, and will always accomplish its task 

```C++
class A {...}
class B {...}
class C {
		A a;
		B b;
	public:
		void f(){
			a.g(); //may throw (strong guarantee)
			b.h(); //may throw (strong guarantee)
		}
};
```

- Is C::f exn safe? 
	- If a.g() throws - nothing has happened yet
	- If b.h() throws - a.g() has already modified state of program
		- Effects of g would have to be undone to offer the strong guarantee 
		- Very hard/impossible if g has non-local side effects
- No, C::f is probably not exn safe
- If A::g and B::h do not have non-local side effects, can use copy and swap

```C++
class C {
	...
	void f(){
		A atemp = a; //if any of the following throw, the original
		B btemp = b; //a and b are still intact
		atemp.g(); //
		btemp.h(); //
		a = atemp; //but what if copy assgnment throws?
		b = btemp; //specifically, what if a = atemp succeeds, but 
				   //b = btemp fails?
	}
};
```

- Better if swap was no throw
- Recall: copying pointers can't throw 
	- Solution: Access C's internal state through a pointer (called the pimpl idiom) 

```C++
struct CImpl{
	A a;
	B b;
};

class C{
	unique_ptr<CImpl> pImpl;
	
	void f(){
		auto temp = make_unique<CImpl>(*pImpl); 
		tmp->a.g();
		tmp->b.h();
		std::swap(pImpl, temp); //no throw
	}
};
```

- Of either A::g or B::h offer no exn safety guarantee, then neither can f

Exception Safety and the STL - Vectors
---

- vectors - encapsulate heap-allocated array
	- Follow RAII - when a stack allocated vector goes out of scope, the internal heap array is freed 

```C++
void f(){
	vector<C> v;
	... 
}; //v goes out of scope, array is freed, C dtor runs on all objects 
   //in the vector

void g(){
	vector<C*> v;
	...
} //the array is freed, pointers don't have dtors, and objects pointed to
  //by the pointers are not deleted 
  //v is not considered to own these objects

void h(){
	vector<unique_ptr<C>>v;
	...
} //array is freed, unique_ptr dtors run, the objects are deleted
  //no explicit deallocation
```

- `vector<C>` - owns the objects
- `vector<C*>` - does not own the objects
- `vector<unique_ptr<C>>` - owns the objects

- `vector<T>::emplace_back` - offers the strong guarantee
	- If the array is full (i.e. size == cap):
		- Allocate a new array
		- Copy objects over (copy ctor) 
		- Delete the old array (no throw) 
	- If a copy ctor throws:
		- Destroy the new array 
		- Old array still intact 
		- Gives the strong guarantee

- However, copying is expensive and we intend to throw away the old array 
	- Moving the objects would be more efficient:
		- Allocate new array
		- Move the objects over (move ctor)
		- Delete the old array (no throw) 
	- If a move ctor throws:
		- Original is no longer intact
		- Can't offer the strong guarantee

- If the move ctor offers the no throw guarantee, emplace_back will use the move ctor
	- Otherwise, it will use the copy ctor, which may be slower 
	- So your move operations **should** offer the no throw guarantee, and you should indicate that they do:

```C++
class C{
	public:
		C (C &&other) noexcept {...}
		C &operator=(C &&other) noexcept {...}
};
```

- If you know a function will never throw or propagate an exception, declare it noexcept
	- Facilitates optimization
	- At minimum - moves and swaps should be noexcept
