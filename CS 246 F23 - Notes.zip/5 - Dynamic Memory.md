Dynamic Memory Management
-------------------------
- C uses calloc/malloc/realloc/free
  but not type-safe since uses (void *)  
  => forbidden in CS246!
- C++ uses: new, delete, and nullptr

```C++
  e.g. int *p1 = nullptr;
       int *p2 = new int;
       *p2 = 5;
       delete p1; // OK!
       delete p2; // OK!
       // delete p1, p2; // NO!
```

"memory leak"  
=> failed to free heap memory  
=> incorrect program (use valgrind)

```C++
int *arr = new int[10]; // new int[10] {0};
...
delete[] arr;
```

- do not mix new ...[...] with delete or new with delete[] ...   
  => unspecified behaviour

Q: How to dynamically allocate a 2-D array? (global constants NUM_ROWS, NUM_COLS)

A: generate pattern: # of "*" ~= # dimensions
```C++
int **ptr;
ptr = new (int *)[NUM_ROWS];
for (int i = 0; i < NUM_ROW; ++i) {
    ptr[i] = new int[NUM_COLS];
    // initiate ptr[i, j]
}
...
for (int i = 0; i < NUM_ROWS; ++i) {
    delete[] ptr[i];
}
delete[] ptr;
```

Returning Info
--------------
Three possible choices:
1) by value
2) by reference
3) by pointer

[Return By Value]
```C++
ReallyBig getStruct() {
    ReallyBig rb;
    return rb;
    // return ReallyBig;
    // return ReallyBig{};
    => "anonymous objects", rvalue
}
```
- makes an expensive copy to return (ellision, discussed later, reduces cost)

[Return By Reference]
```C++
ReallyBig &getStruct() {
    ReallyBig rb;
    return rb;
}
// returns ref. but object "rb" is destroyed when function ends so bound to
// invalid address
```

This is legal:
```C++
ReallyBig &getStruct() {
    return *(new ReallyBig);
}
// caller: ReallyBig &ref = getStruct();
//         delete &ref;
```

[Return By Pointer]
```C++
ReallyBig *getStruct() {
    ReallyBig rb;
    return &rb;
}
// address of local var., therefore destroyed by function end, which
// invalidates the address

ReallyBig *getStruct() {
    ReallyBig *p = new ReallyBig;
    return p;
    // return new ReallyBig;
}
// heap space persists!
```
=> must delete the heap allocated memory

Best practice is to return by value since not as expensive as you might think

Q: stream objects can't be copied so no passing or returning by value - why
   does returning by reference work?

```C++
std::istream &operator>>(std::istream &in, int &value) {
    ...
    return in;
}
```

A: 
```C++
int i;
cin >> i; // operator>>(cin, i)
```

- Since cin isn't local to operator>>, this works!
