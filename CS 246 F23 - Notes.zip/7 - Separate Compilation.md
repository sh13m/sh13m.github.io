Separate Compilation
--------------------
Remember that in C/C++, can declare multiple times (e.g. type existense/forward
declarations, function signatures/prototypes, extern globals) but can only
define once (full function/type implementation; space is allocated for vars.)

Split modules into:
- "interfaces":       fuction prototypes and type definitions
- "implementation":   full definition for every provided function

Interface in modules: export module ___;  
Implementation in modules: module ___;  

[e.g.]
```C++
// module interface: vec.cc
export module vec;
export struct vec {
    int x, y;
};
export vec operator+(const vec &v1, const vec &v2);

// include version: vec.h
#ifndef VEC_H
#define VEC_H
struct vec {
    int x, y;
}
vec operator+(...);
#endif

// module: vec-impl.cc
module vec; // makes interface available
vec operator+(...) {
    return vec{...};
}

// include version: vec.cc
#include "vec.h"
vec operator+(...) {
    return vec{...};
}
```

"-c" creates a partially compiled .o file   
final step is to "link" all .o files together into the executable  
=> can use "-o <name>" to rename the executable from a.out

- modules must be compiled in dependency order
```
    (1) system headers              ‾|
    (2) compile interface files      |- MUST follow dependency order
    (3) compile implementation      _|

[vec.cc] <-- [main.cc] --> <iostream>
    ^
    |
[vec-impl.ccc]
```
```
g++20h iostream
g++20m -c vec.cc
g++20m -c vec-impl.cc main.cc
g++20m *.o -o vecexec
```
Note: could make life simpler with globbing (cheat method)  
g++20m -c *.cc (twice then link)  
will fail compile for a few .cc files first, but running again will work
