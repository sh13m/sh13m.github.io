# Class #18

Course: Computer Science (https://www.notion.so/Computer-Science-f9b44b2c4ee34218a87d90568f0868f2?pvs=21)
Confidence: Not Confident
Last Edited: November 14, 2023 11:16 AM

```cpp
throw out_of_range{"f"}; // .what produces "f"
												 // ctor call with arg "f

// throwing a new exception to our caller
try{...}
catch (SomeErrorType s) {
	... // remediating code
	throw SomeOtherError{...};
}

// rethrowing the same exception
try{...}
catch (SomeErrorType s) {
	...
	throw; // not "throw s;"
}
```

************throw; vs throw s;************

- exceptions are classes and exceptions that we catch are objects
- in this case: exception s can be an object of a subclass of SomeErrorType

![8EEDDBF2-FFDB-453F-B19E-A8F453FABCC9.jpeg](mdimg/8EEDDBF2-FFDB-453F-B19E-A8F453FABCC9.jpeg)

throw s;

→ throwing a new exception of type SomeErrorType

→ s is sliced into type SomeErrorType

throw;

→ rethrows the actual exception that was caught

→ the actual class is retained

```cpp
// catch-all block
try { // ...
}
catch (...) { // ... literally mean ...
// ... can do anything you want
}
```

```cpp
// Exception-based factorial
#include <iostream>
using namespace std;

void fact(int n) {
	if (n == 0) throw 1;
	try {
		fact(n - 1);
	} catch (int m) {
		throw (n * n);
	}
}

int main() {
	int n;
	while (cin >> n) {
		try {
			fact(n);
		} catch (int m) {
			cout << m << endl;
		}
	}
}
```

```cpp
// Exceptions are classes
class BadInput {};

try {
	if (int n; !(cin >> n)) throw BadInput();
} catch (BadInput &) {
	cerr << "Input not well-formed" << endl;
}
```

- catching exceptions by reference

→ exception could belong to a subclass of BadInput

→ catching by value could slice exception

→ catching by reference prevents slicing (treat it like the type that it actually is)

**→** **throw by value, but catch by reference**

```cpp
class BaseExn{};
class DerivedExn : public BaseExn{};

void f() {
	DerivedExn d;
	BaseExn &b = d;
	throw b;
}
...
try{
	f();
} 
catch (DerivedExn &) {...}
catch (BaseExn &) {...} // this will run
												// the type of the red determines the handler
```

- “new” fails → throw “std::bad-alloc”
- whenever exception is raised → all stack-allocated objects are destroyed (dtor runs)

→ should NEVER let dtor throw an exception

→ by default, the program will terminate (std::terminate is called)

→ if the dtor throws during stack unwinding, we have two active exceptions

→ program aborts immediately (call std::terminate again)

```cpp
~X() noexcept(false) {} // NEVER DO THIS
```

****************Problem:****************

- write a video game that has two types of enemies: turtles or bullets
- the system randomly creates enemies
- bullets become more frequent in later (harder) levels

******************Solution:******************

- system does not know which enemy comes next
- the policy that decides what enemy is next should be customizable according to the level
- put a factory method in Level to create Enemies

![4BCB7DC2-E652-47FC-B36F-F0C8D23CCBE9.jpeg](mdimg/4BCB7DC2-E652-47FC-B36F-F0C8D23CCBE9.jpeg)

### Factory Method Pattern

```cpp
class Level {
	public:
		virtual Enemy * createEnemy() = 0; // factory method pattern
	...
};

class Easy : public Level {
	public:
		Enemy * createEnemy() override {
			// create mostly turtles
		}
};

class Hard : public Level {
	public:
		Enemy * createEnemy() override {
			// create mostly bullets
		}
};

// client
Level * = new Easy;
vector<Enemy *> enemies;

for (auto &n : enemies) {
	n = l->createEnemy();
} // most of the position enemies should store a pointer to turtles
// virtual constructor pattern
// factory method pattern
```

******************Problem:******************

- turtles can have red shells and green shells
- subclasses should not change how the turtles are drawn (the steps of drawing turtles) → head, shell, feet

******************Solution:******************

- subclasses can change the way the shell is drawn

### Template Method Pattern

```cpp
class Turtle {
	public:
		void draw() {
			drawHead();
			drawShell();
			drawFeet();
		}

	private:
		void drawHead() {...}
		void drawFeet() {...}
		virtual void drawShell() = 0; // virtual methods can be private
};

class RedTurtle : public Turtle {
	void drawShell() override {//*draw a red shell*}
};

class GreenTurtle : public Turtle {
	void drawShell() override {//*draw a green shell*}
};
```

****Non-virtual Interface (NVI) Idiom****

- public virtual method

→ public: an interface to our client, we have some promises, like the given behaviour

→ promise: pre and post condition and promising class invariants

→ virtual: this works as an interface to our subclasses

→ behaviour can be replaced by anything the subclass wants

- contradiction: we are making promises that are designed to be broken
- NVI idiom says:

→ all public methods should be non-virtual

→ all virtual methods should be private or at least protected

→ except the dtor

```cpp
// Digital media example - NOT following NVI idiom
class DigitalMedia {
	public:
		virtual void play() = 0;
};

// following NVI idiom
class DigitalMedia {
	public:
		void play() {
			doPlay();
		}

	private:
		virtual void doPlay() = 0;
};
```

- if need to modify “play”

→ can add before/after code around doPlay which can’t be changed 

- ex. check for copyright or update playCont after

→ can add more “hooks” by calling other virtual methods from “play” 

- ex. show CovertArt

→ all this without changing the public interface

- the NVI idiom extends the template method pattern

→ every virtual method is inside a non-virtual wrapper

→ there is no disadvantage, compiler can optimize function calls