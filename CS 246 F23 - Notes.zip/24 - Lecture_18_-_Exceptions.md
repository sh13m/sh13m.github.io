
Recall: An exception can depart of the recovery job, throw another exception:

```C++
try {...}
catch (SomeError s){
	...
	throw SomeOtherError {}; 
}

//can rethrow same exception

try {...}
catch (SomeError s){
	...
	throw;
}
```

- `throw;` vs `throw s;` 
- throw:
	- actual type of s is retained
- throw s:
	- s may be a subtype of SomeError
	- Throws a new exception of type SomeError

```mermaid
classDiagram
SpecialError --|> SomeError
class SomeError
class SpecialError
```

- A handler can act as a catch-all:

```C++
try {...}
catch (...){ //catch(...) catches all exceptions
	...
}
```

- You can throw anything you want, not just objects
- When new fails: throws std::bad.alloc

- **Never** let a dtor throw or propagate an exception
	- program will abort immediately 
	- if you want a throwing dtor, you can tag it with `noexecpt(false)` 
	- delete doesn't throw anything, so unlikely to have throwing dtor
- If a dtor throws during stack unwinding while dealing with another exception, you now have 2 active, unhandled exceptions, and the program will abort **immediately** 

**Factory Method Pattern**

- Write a video game with 2 kinds of enemies: turtles and bullets 
	- system randomly sends turtles and bullets, but bullets are more common in the harder levels

```mermaid
classDiagram
Bullet --|> Enemy
Turtle --|> Enemy
class Enemy
class Turtle
class Bullet

Easy --|> Level
Hard --|> Level
class Level
class Easy
class Hard
```

- Never know exactly which enemy comes next, so can't call turtle/bullet ctors directly
- Factory method - method that "creates things"
- Instead, put a factory method in Level that creates enemies: 

```C++
class Level{
	public:
		virtual Enemy *createEnemy() = 0; //factory method
};

class Easy:public Level{
	public:
		Enemy *createEnemy() override{ //create mostly turtles
			...
		}
};

class Hard:public Level{
	public:
		Enemy *createEnemy() override{ //create mostly bullets
			...
		}
};

Level *l = new Easy;
Enemy *e = l->createEnemy();
```

**Template Method Patterns**

- Want subclasses to override superclass behaviour, but some aspects must stay the same 
- Example: There are red turtles and green turtles 

```C++
class Turtle{
	public:
		void draw(){
			drawHead();
			drawShell();
			drawFeet();
		}
	private:
		void drawHead(){...}
		void drawFeet(){...}
		virtual void drawShell() = 0;
};

class RedTurtle:public Turtle{
	void drawShell()override { //draws a red shell
		...
	}
};

class GreenTurtle:public Turtle{
	void drawShell()override { //draws a green shell
		...
	}
};
```

- Subclasses can't change the way a Turtle is drawn (head, shell, feet), but can change the way the shell is drawn 
	- Like filling out blanks in a form/template 

**Generalization: The Non-Virtual Interface (NVI) Idiom** 

- A public virtual method is really 2 things: 
	- public: an interface to the client
		- promises certain behaviour with pre/post conditions
	- virtual: an interface to subclasses
		- the behaviour can be replaced with anything the subclass wants 
- Public + virtual -> making promises you can't keep 

- NVI: all public methods should be non-virtual
	- all virtual methods should be private or protected 
	- except the dtor 

- Example: Digital Media
	- Without DVI

```C++
class DigitalMedia{
	public:
		virtual void play() = 0;
};
```

- With DVI

```C++
class DigitalMedia{
	public:
		void play(){
			//can add checkCopyright();
			doPlay();
			//can add updatePlayCount();
		}
	private:
		virtual void doPlay() = 0;
};
```

- Generalizes Template Method:
	- Every virtual method should be called from within a template method 

**STL Maps - for creating dictionaries**

- Example: "arrays" that map strings to ints 

```C++
import <map>;

std::map <std::string, int> m;
m["abc"] = 2;
m["def"] = 3;

cout << m["ghi"] //0, key isn't present, so it is inserted and the value is
				 //default constructed (0 for ints)
	 << m["def"]; //3
```

