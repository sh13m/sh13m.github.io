Arrays of Objects
-----------------
- can only be created if the class has a default ctor  
  
[e.g.]
```C++
struct Vec {
    int x, y;
    Vec(int x, int y);
}
Vec arr1[10];
Vec *arr2 = new Vec[5];
// both are currently illegal
```
Three possible fixes:
1) Provide a default ctor (not always possible)


2) Invoke ctors as declare array  
    [e.g.] ```Vec arr3[3] = {Vec{0,1}, Vec{1,0}, Vec{1,1}};```  
    => works, but doesn't scale up

3) Use an array of pointers   
    [e.g.] 
    ```
    Vec *arr4[2500] {nullptr};
    ... arr4[997] = new Vec{2,3};
    ```


Const Objects
-------------
- usually occurs because passing an object as a constant reference  
  
[e.g.]
```C++
struct Student {
    int assns, mt, final;
    float grade();
};

ostream &operator<<(ostream &out, const Student &s) {
    out << s.assns << " " << s.mt << " " << s.final << " " << s.grade(); // illegal
    return out;
}
```
=> call can't be made since s is a constant obj. and Student::grade() doesn't
   promise it won't change the object's data fields  
=> declare grade() as "const" in both interface and inplementation files  
[e.g.]
```C++
struct Student {
    ...
    float grade() const;
    ...
};

float Student::grade() const {
    ...
}
```
=> compiler will complain if const method attempts to change the reciever
   object's ("this") data fields

physical constness : any data fields' values have changed after an update  
logical constness : update has changed some field that is what the client
                    cares about

- for example, want to profile # of method calls for a student  

[e.g.]
```C++
struct Student {
    int numCalls = 0;       // physical constness
    int assns, mt, final;   // physical constness, logical constness
    ...
};
```
=> want Student::grade() to increment "numCalls" every time it's invoked  
=> have to tell compiler that numCalls is part of physical and not logical
   constness since Student::grade() is now const  
=> declare numCalls to be "mutable"  
    [e.g.]
```C++
struct Student {
    mutable int numCalls = 0;
    ...
};
```