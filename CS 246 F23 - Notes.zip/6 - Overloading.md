Overloading Operators
---------------------
- in C++, can also overload operators

```C++
e.g. struct vec {int x, y;};
     vec v1;            // uninitialized
     vec v2{2, 3};      // field initialization
     vec v3 = v2;       // x = 2, y = 3
     v1.x = 0;
     v1.y = 1;
```

want to be able to "scale" a vector object by an int
```C++
v2 = 3  * v1;
v3 = v1 * 16;

vec operator*(const vec &other, int s) {
    vec res{other.x * s, other.y * s};
    return res;
    // return vec{other.x * s, other.y * s};
}

vec operator*(int s, const vec &other) {
    return (other * s); // call to first case
}
```

Overloading I/O is a special case  
Consider a grade; must in range 0-100 and output as "87%"  
[e.g.]
```C++
stuct Grade {std::size_t g;};
istream &operator>>(std::istream &in, Grade &g) {
    int val;
    in >> val;
    if (val < 0) g.g = 0;
    else if (val > 100) g.g = 100;
    else g.g = val;
    return in;
}

ostream &operator<<(ostream &out, const Grade &g) {
    out << g.g << "%";
    return out;
}
```